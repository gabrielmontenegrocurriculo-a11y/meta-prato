export const todayKey = () => new Date().toISOString().slice(0, 10);

export const formatDateLong = (date = new Date()) =>
  new Intl.DateTimeFormat("pt-BR", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric"
  }).format(date);

export const formatTime = (date = new Date()) =>
  new Intl.DateTimeFormat("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  }).format(date);

export const timeOnly = (date = new Date()) => date.toTimeString().slice(0, 5);

export const daysBetween = (a: Date, b: Date) => {
  const start = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
  const end = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
  return Math.floor((end - start) / 86400000);
};

export const addDays = (date: Date, days: number) => {
  const copy = new Date(date);
  copy.setDate(copy.getDate() + days);
  return copy;
};

export const dateKeyFrom = (date: Date) => date.toISOString().slice(0, 10);

export const isSameWeek = (dateKey: string, now = new Date()) => {
  const date = new Date(`${dateKey}T12:00:00`);
  const start = new Date(now);
  start.setDate(now.getDate() - now.getDay());
  start.setHours(0, 0, 0, 0);
  const end = addDays(start, 7);
  return date >= start && date < end;
};

export const isSameMonth = (dateKey: string, now = new Date()) => {
  const date = new Date(`${dateKey}T12:00:00`);
  return date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth();
};
