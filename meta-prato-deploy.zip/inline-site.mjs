import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";

const root = process.cwd();
const dist = join(root, "dist");
const output = join(root, "outputs", "meta-prato-site.html");

const index = readFileSync(join(dist, "index.html"), "utf8");
const cssPath = index.match(/href="\.\/(assets\/[^"]+\.css)"/)?.[1];
const jsPath = index.match(/src="\.\/(assets\/[^"]+\.js)"/)?.[1];

if (!cssPath || !jsPath) {
  throw new Error("Nao encontrei os assets do build para embutir.");
}

const css = readFileSync(join(dist, cssPath), "utf8");
const js = readFileSync(join(dist, jsPath), "utf8").replaceAll("</script", "<\\/script");

const html = index
  .replace(/<link rel="manifest"[^>]+>\s*/g, "")
  .replace(/<link rel="apple-touch-icon"[^>]+>\s*/g, "")
  .replace(/<script type="module" crossorigin src="\.\/assets\/[^"]+\.js"><\/script>/, () => `<script>${js}</script>`)
  .replace(/<link rel="stylesheet" crossorigin href="\.\/assets\/[^"]+\.css">/, () => `<style>${css}</style>`);

mkdirSync(dirname(output), { recursive: true });
writeFileSync(output, html);

console.log(output);
