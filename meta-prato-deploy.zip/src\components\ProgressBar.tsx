import { clamp } from "../lib/metrics";

type Props = {
  value: number;
  label?: string;
};

export function ProgressBar({ value, label }: Props) {
  const safe = clamp(value);
  return (
    <div className="space-y-2">
      {label ? (
        <div className="flex items-center justify-between text-sm text-muted">
          <span>{label}</span>
          <strong className="text-bone">{Math.round(safe)}%</strong>
        </div>
      ) : null}
      <div className="h-4 overflow-hidden rounded-sm border border-graphite bg-base">
        <div className="h-full bg-signal transition-all" style={{ width: `${safe}%` }} />
      </div>
    </div>
  );
}
