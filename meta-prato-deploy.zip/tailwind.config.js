/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        base: "#050705",
        panel: "#111712",
        panel2: "#1c241f",
        field: "#242a26",
        tactical: "#6f8057",
        signal: "#9fbf7f",
        graphite: "#343a36",
        bone: "#e8eee2",
        muted: "#aeb8aa",
        danger: "#d6a15f"
      },
      boxShadow: {
        tactical: "0 18px 45px rgba(0,0,0,.36)"
      }
    }
  },
  plugins: []
};
