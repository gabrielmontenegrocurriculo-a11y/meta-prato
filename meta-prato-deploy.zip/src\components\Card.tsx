import type { ReactNode } from "react";

type Props = {
  title?: string;
  children: ReactNode;
  className?: string;
};

export function Card({ title, children, className = "" }: Props) {
  return (
    <section className={`rounded-md border border-graphite bg-panel p-4 shadow-tactical ${className}`}>
      {title ? <h2 className="mb-4 text-lg font-black uppercase tracking-normal text-bone">{title}</h2> : null}
      {children}
    </section>
  );
}
