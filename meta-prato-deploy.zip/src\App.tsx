import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from "react";
import { ActionButton } from "./components/ActionButton";
import { ProgressBar } from "./components/ProgressBar";
import { daysBetween, formatDateLong, formatTime, timeOnly, todayKey } from "./lib/date";
import {
  addXp,
  dailyProgress,
  daysRemainingToGoal,
  estimateMealGrams,
  getTodayChecklist,
  getWaterToday,
  levelForXp,
  monthlyProgress,
  monthlyUnlocked,
  nextReward,
  updateStreak,
  weeklyProgress,
  weeklyUnlocked,
  weightGoalForDay
} from "./lib/metrics";
import { findPatient, getAllPatients, getServerPatients, passwordRules, registerPatient, syncPatientToServer, updateStoredPatient, type PatientForm } from "./lib/patients";
import { clearSessionPatientId, defaultChecklist, loadData, loadServerData, loadSessionPatientId, saveData, saveServerData, saveSessionPatientId } from "./lib/storage";
import type { AppData, ChecklistState, Meal, Patient, PlannedMeal, WeightEntry } from "./types";

const checklistLabels: Record<keyof ChecklistState, string> = {
  mealRegistered: "Registrei refeicao",
  platePhoto: "Tirei foto do prato",
  water: "Bebi agua",
  noRepeat: "Nao repeti prato",
  withinGoal: "Comi dentro da meta",
  weightRegistered: "Registrei peso"
};

const navItems = [
  ["Painel", "H"],
  ["Refeicoes", "R"],
  ["Agua", "A"],
  ["Peso", "P"],
  ["Rotina", "T"],
  ["Historico", "L"],
  ["Missoes", "M"],
  ["Recompensas", "C"]
];

const rewardExamples = ["1 lanche favorito", "1 prato especial", "1 sobremesa pequena", "Cinema", "Presente pequeno"];
const superRewardExamples = ["Restaurante", "Combo especial", "Cinema", "Jogo", "Livro ou presente"];
type AuthMode = "welcome" | "create" | "login" | "recover" | "created";

const mounjaroSymptoms = ["Nausea", "Azia", "Prisao de ventre", "Diarreia", "Tontura", "Falta de fome", "Fraqueza"];
const moodOptions = ["Otimo", "Bem", "Normal", "Desanimado", "Muito dificil"];
const reflectionOptions = ["Agua", "Fome", "Vontade de doce", "Cansaco", "Ansiedade", "Outro"];

const foodLibrary = [
  { name: "Arroz", calories: 1.3, protein: 0.03, carbs: 0.28, fat: 0.003 },
  { name: "Carne", calories: 2.5, protein: 0.26, carbs: 0, fat: 0.16 },
  { name: "Frango", calories: 1.65, protein: 0.31, carbs: 0, fat: 0.04 },
  { name: "Batata", calories: 0.86, protein: 0.02, carbs: 0.2, fat: 0.001 },
  { name: "Pizza", calories: 2.66, protein: 0.11, carbs: 0.33, fat: 0.1 },
  { name: "Hamburguer", calories: 2.95, protein: 0.17, carbs: 0.28, fat: 0.14 },
  { name: "Refrigerante", calories: 0.42, protein: 0, carbs: 0.11, fat: 0 },
  { name: "Suco", calories: 0.48, protein: 0.004, carbs: 0.12, fat: 0.001 }
];

const rankTable = [
  ["Recruta", 0],
  ["Soldado", 300],
  ["Cabo", 700],
  ["Sargento", 1200],
  ["Tenente", 1800],
  ["Capitao", 2600],
  ["Major", 3600],
  ["Coronel", 5000],
  ["General", 7000]
] as const;

export default function App() {
  const [currentPatient, setCurrentPatient] = useState<Patient | null>(() => {
    const sessionId = loadSessionPatientId();
    return getAllPatients().find((patient) => patient.id === sessionId) ?? null;
  });
  const [data, setData] = useState<AppData>(() => loadData(currentPatient ?? undefined));
  const [loginEmail, setLoginEmail] = useState("gabriel@metaprato.app");
  const [loginPassword, setLoginPassword] = useState("Senha@123");
  const [loginError, setLoginError] = useState("");
  const [authMode, setAuthMode] = useState<AuthMode>("welcome");
  const [rememberMe, setRememberMe] = useState(true);
  const [recoveryEmail, setRecoveryEmail] = useState("");
  const [recoverySent, setRecoverySent] = useState(false);
  const [createStep, setCreateStep] = useState(1);
  const [pendingPatient, setPendingPatient] = useState<Patient | null>(null);
  const [pendingData, setPendingData] = useState<AppData | null>(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [onboardingStep, setOnboardingStep] = useState(1);
  const [onboarding, setOnboarding] = useState({
    currentWeight: data.currentWeight,
    targetWeight: data.targetWeight,
    objective: "lose" as Patient["objective"],
    monthlyWeightGoal: 5,
    weeklyReward: "Cinema",
    monthlyReward: "Restaurante"
  });
  const [patientList, setPatientList] = useState<Patient[]>(() => getAllPatients());
  const [registerForm, setRegisterForm] = useState<PatientForm>({
    name: "",
    nickname: "",
    birthDate: "",
    sex: "",
    email: "",
    confirmEmail: "",
    cpf: "",
    password: "",
    confirmPassword: "",
    age: 0,
    heightCm: 170,
    initialWeight: 160,
    targetWeight: 100,
    doctor: "",
    plan: "",
    notes: "",
    acceptedTerms: false,
    acceptedPrivacy: false
  });
  const [clock, setClock] = useState(new Date());
  const [mealName, setMealName] = useState("Almoco");
  const [mealNote, setMealNote] = useState("");
  const [mealGrams, setMealGrams] = useState(420);
  const [mealAnalysis, setMealAnalysis] = useState(analyzeMeal(420, "Almoco"));
  const [photo, setPhoto] = useState("");
  const [barcode, setBarcode] = useState("");
  const [manualFood, setManualFood] = useState("");
  const [symptomText, setSymptomText] = useState("");
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [strongSymptoms, setStrongSymptoms] = useState(false);
  const [rewardName, setRewardName] = useState("");
  const [rewardCost, setRewardCost] = useState(500);
  const [bodyPhotoNote, setBodyPhotoNote] = useState("");
  const [bodyPhotoAngle, setBodyPhotoAngle] = useState<"front" | "side" | "back">("front");
  const [bodyMeasure, setBodyMeasure] = useState({ waist: 0, chest: 0, arm: 0, thigh: 0, neck: 0 });
  const [marketName, setMarketName] = useState("");
  const [marketType, setMarketType] = useState<"shopping" | "favorite" | "blocked">("shopping");
  const [emergencyOpen, setEmergencyOpen] = useState(false);
  const [notificationStatus, setNotificationStatus] = useState("Lembretes desligados");
  const [healthDraft, setHealthDraft] = useState(data.healthProfile);
  const [focusMode, setFocusMode] = useState(false);
  const [soundOn, setSoundOn] = useState(true);
  const [rewardBoxOpen, setRewardBoxOpen] = useState(false);
  const [habitName, setHabitName] = useState("");
  const [voiceText, setVoiceText] = useState("");
  const [travelLocation, setTravelLocation] = useState(data.travelMode.location);
  const [travelShift, setTravelShift] = useState(data.travelMode.timeShift);
  const [objectiveText, setObjectiveText] = useState("");
  const [timeCapsuleText, setTimeCapsuleText] = useState(data.timeCapsule);
  const [simLoss, setSimLoss] = useState(5);
  const [todayPlan, setTodayPlan] = useState("Ficar em casa");
  const [searchQuery, setSearchQuery] = useState("");
  const [dayFeedback, setDayFeedback] = useState("");
  const [isOnline, setIsOnline] = useState(() => navigator.onLine);
  const [checkup, setCheckup] = useState({ bloodPressure: "", glucose: 0, heartRate: 0, examNote: "" });
  const [sleepDraft, setSleepDraft] = useState({ sleptAt: "23:00", wokeAt: "07:00", quality: "Normal" });
  const [watchDraft, setWatchDraft] = useState({ steps: 0, heartRate: 0, exerciseMinutes: 0, sleepHours: 0, source: "Manual" as "Apple Watch" | "Wear OS" | "Manual" });
  const [economyDraft, setEconomyDraft] = useState({ snackRewards: data.snackRewards ?? 0, snackSpent: data.snackSpent ?? 0, homeSavings: data.homeSavings ?? 0 });
  const [plannedName, setPlannedName] = useState("Almoco");
  const [plannedTime, setPlannedTime] = useState("13:00");
  const [weightInput, setWeightInput] = useState(data.currentWeight);

  useEffect(() => {
    const timer = window.setInterval(() => setClock(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    void getServerPatients().then(setPatientList);
  }, []);

  useEffect(() => {
    const updateOnline = () => setIsOnline(navigator.onLine);
    window.addEventListener("online", updateOnline);
    window.addEventListener("offline", updateOnline);
    return () => {
      window.removeEventListener("online", updateOnline);
      window.removeEventListener("offline", updateOnline);
    };
  }, []);

  useEffect(() => {
    if (!currentPatient) return;
    saveData(data, currentPatient.id);
    if (navigator.onLine) void saveServerData(data, currentPatient.id);
  }, [currentPatient, data]);

  useEffect(() => {
    setHealthDraft(data.healthProfile);
    setTimeCapsuleText(data.timeCapsule ?? "");
    setDayFeedback((data.dailyFeedback ?? {})[todayKey()] ?? "");
    setEconomyDraft({ snackRewards: data.snackRewards ?? 0, snackSpent: data.snackSpent ?? 0, homeSavings: data.homeSavings ?? 0 });
  }, [data.patientId]);

  const todayChecklist = getTodayChecklist(data);
  const waterToday = getWaterToday(data);
  const waterPercent = Math.min(100, Math.round((waterToday / data.waterGoalMl) * 100));
  const latestMeals = data.meals.slice(-4).reverse();
  const latestWeights = data.weights.slice(-8);
  const daily = dailyProgress(data);
  const weekly = weeklyProgress(data);
  const monthly = monthlyProgress(data);
  const level = levelForXp(data.xp);
  const xpInLevel = data.xp % 300;
  const dayGoal = weightGoalForDay(data);
  const weightLost = Math.max(0, data.initialWeight - data.currentWeight);
  const remainingMealGrams = Math.max(0, 1000 - data.meals.filter((meal) => meal.date === todayKey()).reduce((sum, meal) => sum + meal.grams, 0));
  const waterReminders = useMemo(() => buildWaterReminders(data.wakeTime, data.sleepTime), [data.wakeTime, data.sleepTime]);
  const rank = rankForXp(data.xp);
  const bmi = bmiFor(data.currentWeight, currentPatient?.heightCm ?? 170);
  const totalToLose = Math.max(1, data.initialWeight - data.targetWeight);
  const progressPercent = Math.round((weightLost / totalToLose) * 100);
  const remainingKg = Math.max(0, data.currentWeight - data.targetWeight);
  const weeklyAverageLoss = averageWeightLoss(data.weights, 7);
  const monthlyAverageLoss = averageWeightLoss(data.weights, 30);
  const predictedGoalDate = predictGoalDate(data.currentWeight, data.targetWeight, weeklyAverageLoss);
  const safetyWarnings = safetyAlerts(data);
  const latestMeal = data.meals[data.meals.length - 1];
  const personalRanking = personalRankingStats(data);
  const coachMessages = aiCoachMessages(data, waterToday, remainingKg, data.moodByDate?.[todayKey()]);
  const appStats = centralStats(data);
  const achievements = achievementList(data);
  const specialMissions = specialMissionList(data);
  const journey = journeyMap(data);
  const predictions = forecastWeights(data.currentWeight, data.targetWeight, weeklyAverageLoss);
  const smartGoals = smartGoalTargets(data);
  const avatar = avatarState(data, rank.name);
  const campaign = campaignMap(data);
  const trophyItems = trophyRoomItems(data, achievements, specialMissions);
  const specialTitles = specialTitlesFor(data);
  const milestone = milestoneState(data);
  const intelligence = intelligenceInsights(data);
  const widgets = widgetPreview(data, waterToday, plannedName, plannedTime);
  const jarvisMessages = jarvisMode(data, currentPatient?.name ?? "operador", waterToday, remainingKg);
  const legacy = legacyMode(data);
  const records = personalRecords(data);
  const timeline = timelineEvents(data);
  const interactiveMap = interactiveMapSteps(data);
  const simulatorDate = simulateGoalDate(data.currentWeight, data.targetWeight, simLoss);
  const planAdvice = planningAdvice(todayPlan);
  const hall = hallOfFame(data, rank.name, achievements, specialMissions);
  const journeyMemories = memoriesOfJourney(data);
  const milestoneSystem = milestoneSystemList(data);
  const worldMap = worldMapProgress(weightLost);
  const dataCenter = dataCenterStats(data, weekly, monthly);
  const predictionText = predictionSystemText(data, weeklyAverageLoss);
  const finalMission = finalMissionState(data);
  const searchResults = globalSearch(data, searchQuery);
  const seasonalEvents = seasonalEventList(data);
  const sleepStats = sleepAnalytics(data);
  const moodStats = moodAnalytics(data);
  const challengeList = challengesFor(data);
  const collectibles = collectiblesFor(data);
  const analytics = analyticsPanel(data);
  const dailyMission = missionOfDay(data, waterToday, daily);
  const monthlyMission = monthlyMissionFor(data);
  const inventory = inventoryFor(data, achievements, specialTitles, rank.name);
  const advancedInsights = advancedInsightCenter(data);
  const riskRadar = riskRadarFor(data, waterToday);
  const futureSelf = futureSelfForecast(data, weeklyAverageLoss);
  const lifeOs = lifeOsModules(data);
  const biography = biographyWriter(data, currentPatient?.name ?? "Operador", rank.name);
  const island = evolutionIsland(data);
  const pet = virtualPet(data, rank.name);
  const skillTree = skillTreeFor(data);

  const commitData = (next: AppData) => {
    if (data.settings?.haptics && "vibrate" in navigator) navigator.vibrate(18);
    const queued = navigator.onLine ? next.syncQueue ?? [] : [...(next.syncQueue ?? []), `${todayKey()} ${timeOnly()} alteracao local`];
    setData(updateStreak({ ...next, syncQueue: queued }));
  };

  const updateChecklist = (key: keyof ChecklistState, value = true, base = data) => {
    const date = todayKey();
    return {
      ...base,
      checklistByDate: {
        ...base.checklistByDate,
        [date]: {
          ...(base.checklistByDate[date] ?? defaultChecklist()),
          [key]: value
        }
      }
    };
  };

  const handleWake = () => commitData({ ...data, wakeTime: timeOnly() });

  const handlePhoto = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result);
      const grams = estimateMealGrams(file);
      const analysis = analyzeMeal(grams, file.name);
      setPhoto(result);
      setMealGrams(grams);
      setMealAnalysis(analysis);
      commitData(addXp(updateChecklist("platePhoto"), 20));
    };
    reader.readAsDataURL(file);
  };

  const handleMeal = (event: FormEvent) => {
    event.preventDefault();
    const withinGoal = mealGrams <= data.mealTargetGrams;
    const meal: Meal = {
      id: crypto.randomUUID(),
      date: todayKey(),
      time: timeOnly(),
      photo,
      name: mealName || "Refeicao",
      grams: mealGrams,
      foods: mealAnalysis.foods,
      calories: mealAnalysis.calories,
      protein: mealAnalysis.protein,
      carbs: mealAnalysis.carbs,
      fat: mealAnalysis.fat,
      aiMessage: mealAnalysis.message,
      note: mealNote,
      withinGoal
    };
    let next = { ...data, meals: [...data.meals, meal], coins: (data.coins ?? 0) + 8 };
    next = updateChecklist("mealRegistered", true, next);
    next = updateChecklist("withinGoal", withinGoal, next);
    if (photo) next = updateChecklist("platePhoto", true, next);
    next = addXp(next, 35 + (photo ? 20 : 0) + (withinGoal ? 25 : 0));
    commitData(next);
    setMealNote("");
    setPhoto("");
  };

  const handleMealGramsChange = (grams: number) => {
    setMealGrams(grams);
    setMealAnalysis(analyzeMeal(grams, mealName));
  };

  const scanBarcode = (event: FormEvent) => {
    event.preventDefault();
    const product = productFromBarcode(barcode, manualFood);
    const next = {
      ...data,
      barcodeItems: [
        ...(data.barcodeItems ?? []),
        { id: crypto.randomUUID(), date: todayKey(), code: barcode || "7890000000000", ...product }
      ]
    };
    commitData(addXp(next, 15));
    setBarcode("");
    setManualFood("");
  };

  const registerSymptom = (event: FormEvent) => {
    event.preventDefault();
    const text = [...selectedSymptoms, symptomText.trim()].filter(Boolean).join(", ");
    if (!text) return;
    commitData({
      ...data,
      symptoms: [...(data.symptoms ?? []), { id: crypto.randomUUID(), date: todayKey(), time: timeOnly(), text, strong: strongSymptoms }]
    });
    setSymptomText("");
    setSelectedSymptoms([]);
    setStrongSymptoms(false);
  };

  const addShopReward = (event: FormEvent) => {
    event.preventDefault();
    if (!rewardName.trim()) return;
    commitData({
      ...data,
      shopRewards: [
        ...(data.shopRewards ?? []),
        { id: crypto.randomUUID(), name: rewardName.trim(), cost: Math.max(1, rewardCost) }
      ]
    });
    setRewardName("");
    setRewardCost(500);
  };

  const handleBodyPhoto = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      commitData({
        ...data,
        bodyPhotos: [
          ...(data.bodyPhotos ?? []),
          { id: crypto.randomUUID(), date: todayKey(), image: String(reader.result), note: bodyPhotoNote || "Foto semanal", angle: bodyPhotoAngle }
        ]
      });
      setBodyPhotoNote("");
    };
    reader.readAsDataURL(file);
  };

  const saveBodyMeasure = (event: FormEvent) => {
    event.preventDefault();
    commitData({
      ...data,
      bodyMeasures: [...(data.bodyMeasures ?? []), { id: crypto.randomUUID(), date: todayKey(), ...bodyMeasure }]
    });
  };

  const addMarketItem = (event: FormEvent) => {
    event.preventDefault();
    if (!marketName.trim()) return;
    commitData({
      ...data,
      marketItems: [...(data.marketItems ?? []), { id: crypto.randomUUID(), name: marketName.trim(), type: marketType }]
    });
    setMarketName("");
  };

  const toggleMarketItem = (id: string) => {
    commitData({
      ...data,
      marketItems: (data.marketItems ?? []).map((item) => (item.id === id ? { ...item, done: !item.done } : item))
    });
  };

  const enableNotifications = async () => {
    if (!("Notification" in window)) {
      setNotificationStatus("Este navegador nao suporta notificacoes.");
      return;
    }
    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      setNotificationStatus("Lembretes ativos");
      new Notification("Meta Prato", { body: "Lembretes de agua, refeicao, peso, foto e dormir ativados." });
    } else {
      setNotificationStatus("Permissao de notificacao negada");
    }
  };

  const generatePdfReport = () => {
    if (!currentPatient) return;
    const report = buildReportHtml(data, currentPatient);
    const win = window.open("", "_blank");
    if (!win) return;
    win.document.write(report);
    win.document.close();
    win.focus();
    win.print();
  };

  const saveHealthProfile = (event: FormEvent) => {
    event.preventDefault();
    commitData({ ...data, healthProfile: healthDraft });
  };

  const setMood = (mood: string) => {
    commitData({ ...data, moodByDate: { ...(data.moodByDate ?? {}), [todayKey()]: mood } });
  };

  const playMissionSound = (kind: "mission" | "water" | "rank" | "reward") => {
    if (!soundOn) return;
    const context = new AudioContext();
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    const frequencies = { mission: 440, water: 620, rank: 760, reward: 880 };
    oscillator.frequency.value = frequencies[kind];
    oscillator.connect(gain);
    gain.connect(context.destination);
    gain.gain.setValueAtTime(0.08, context.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + 0.35);
    oscillator.start();
    oscillator.stop(context.currentTime + 0.35);
  };

  const openRewardBox = () => {
    setRewardBoxOpen(true);
    playMissionSound("reward");
    commitData({
      ...data,
      xp: data.xp + 50,
      openedRewardBoxes: [...(data.openedRewardBoxes ?? []), todayKey()],
      achievements: [...new Set([...data.achievements, "Caixa de recompensa aberta"])]
    });
  };

  const saveReflection = (value: string) => {
    commitData({ ...data, reflectionByDate: { ...(data.reflectionByDate ?? {}), [todayKey()]: value } });
  };

  const shareProgress = () => {
    const text = `META PRATO\n\nPeso inicial: ${data.initialWeight} kg\nPeso atual: ${data.currentWeight} kg\nPerdidos: ${weightLost.toFixed(1)} kg\nSequencia: ${data.streak} dias\nPatente: ${rank.name}\nProxima meta: ${nextCampaignTarget(data)} kg`;
    const win = window.open("", "_blank");
    if (!win) return;
    win.document.write(`<pre style="font:700 24px Arial;white-space:pre-wrap;background:#050705;color:#dce9b7;padding:32px;border:8px solid #8fb24e">${text}</pre>`);
    win.document.close();
    win.focus();
    win.print();
  };

  const addHabit = (event: FormEvent) => {
    event.preventDefault();
    if (!habitName.trim()) return;
    commitData({ ...data, habits: [...(data.habits ?? []), { id: crypto.randomUUID(), name: habitName.trim(), doneDates: [] }] });
    setHabitName("");
  };

  const toggleHabit = (habitId: string) => {
    commitData({
      ...data,
      habits: (data.habits ?? []).map((habit) => {
        if (habit.id !== habitId) return habit;
        const done = habit.doneDates.includes(todayKey());
        return { ...habit, doneDates: done ? habit.doneDates.filter((date) => date !== todayKey()) : [...habit.doneDates, todayKey()] };
      })
    });
  };

  const saveTravelMode = (event: FormEvent) => {
    event.preventDefault();
    commitData({ ...data, travelMode: { active: true, location: travelLocation, timeShift: travelShift } });
  };

  const disableTravelMode = () => {
    commitData({ ...data, travelMode: { active: false, location: "", timeShift: 0 } });
  };

  const exportDataFile = (format: "csv" | "xls") => {
    const content = exportTable(data);
    const blob = new Blob([content], { type: "text/csv;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `meta-prato.${format === "xls" ? "xls" : "csv"}`;
    link.click();
    URL.revokeObjectURL(link.href);
  };

  const exportJsonBackup = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "meta-prato-backup.json";
    link.click();
    URL.revokeObjectURL(link.href);
  };

  const restoreJsonBackup = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const restored = JSON.parse(String(reader.result));
        commitData({ ...data, ...restored, patientId: data.patientId });
      } catch {
        setLoginError("Backup invalido.");
      }
    };
    reader.readAsText(file);
  };

  const registerVoiceMeal = (event: FormEvent) => {
    event.preventDefault();
    if (!voiceText.trim()) return;
    const command = parseVoiceCommand(voiceText);
    if (command.type === "water") {
      addWater(command.amount);
      setVoiceText("");
      return;
    }
    if (command.type === "weight") {
      setWeightInput(command.weight);
      const entry: WeightEntry = { id: crypto.randomUUID(), date: todayKey(), weight: command.weight };
      let next = { ...data, currentWeight: command.weight, weights: [...data.weights, entry], coins: (data.coins ?? 0) + 10 };
      next = updateChecklist("weightRegistered", true, next);
      commitData(addXp(next, 25));
      setVoiceText("");
      return;
    }
    const analysis = analyzeVoiceMeal(voiceText);
    const meal: Meal = {
      id: crypto.randomUUID(),
      date: todayKey(),
      time: timeOnly(),
      name: analysis.name,
      grams: analysis.grams,
      foods: analysis.foods,
      calories: analysis.calories,
      protein: analysis.protein,
      carbs: analysis.carbs,
      fat: analysis.fat,
      aiMessage: analysis.message,
      note: `Registro por voz: ${voiceText}`,
      withinGoal: analysis.grams <= data.mealTargetGrams
    };
    let next = { ...data, meals: [...data.meals, meal] };
    next = updateChecklist("mealRegistered", true, next);
    next = updateChecklist("withinGoal", meal.withinGoal, next);
    commitData(addXp(next, 30));
    setVoiceText("");
  };

  const saveDailyFeedback = (event: FormEvent) => {
    event.preventDefault();
    commitData({ ...data, dailyFeedback: { ...(data.dailyFeedback ?? {}), [todayKey()]: dayFeedback } });
  };

  const updateTheme = (theme: AppData["settings"]["theme"]) => {
    commitData({ ...data, settings: { ...data.settings, theme } });
  };

  const toggleSetting = (key: keyof AppData["settings"]) => {
    if (key === "theme") return;
    commitData({ ...data, settings: { ...data.settings, [key]: !data.settings[key] } });
  };

  const addObjective = (event: FormEvent) => {
    event.preventDefault();
    if (!objectiveText.trim()) return;
    commitData({ ...data, objectives: [...(data.objectives ?? []), { id: crypto.randomUUID(), text: objectiveText.trim() }] });
    setObjectiveText("");
  };

  const toggleObjective = (id: string) => {
    commitData({
      ...data,
      objectives: (data.objectives ?? []).map((objective) => objective.id === id ? { ...objective, done: !objective.done } : objective)
    });
  };

  const saveTimeCapsule = (event: FormEvent) => {
    event.preventDefault();
    commitData({ ...data, timeCapsule: timeCapsuleText });
  };

  const claimMiniGame = () => {
    commitData({
      ...data,
      xp: data.xp + 75,
      coins: (data.coins ?? 0) + 25,
      achievements: [...new Set([...data.achievements, "Item cosmetico desbloqueado"])]
    });
    playMissionSound("mission");
  };

  const saveCheckup = (event: FormEvent) => {
    event.preventDefault();
    commitData({
      ...data,
      checkups: [...(data.checkups ?? []), { id: crypto.randomUUID(), date: todayKey(), ...checkup }]
    });
  };

  const saveSleep = (event: FormEvent) => {
    event.preventDefault();
    const hours = sleepHours(sleepDraft.sleptAt, sleepDraft.wokeAt);
    commitData({
      ...data,
      sleeps: [...(data.sleeps ?? []), { id: crypto.randomUUID(), date: todayKey(), ...sleepDraft, hours }]
    });
  };

  const saveWatch = (event: FormEvent) => {
    event.preventDefault();
    commitData({
      ...data,
      watchEntries: [...(data.watchEntries ?? []), { id: crypto.randomUUID(), date: todayKey(), ...watchDraft }]
    });
  };

  const saveEconomy = (event: FormEvent) => {
    event.preventDefault();
    commitData({ ...data, ...economyDraft });
  };

  const claimShopReward = (rewardId: string) => {
    const reward = (data.shopRewards ?? []).find((item) => item.id === rewardId);
    if (!reward || reward.claimed || data.xp < reward.cost) return;
    commitData({
      ...data,
      xp: data.xp - reward.cost,
      shopRewards: (data.shopRewards ?? []).map((item) => (item.id === rewardId ? { ...item, claimed: true } : item)),
      achievements: [...new Set([...data.achievements, `Recompensa resgatada: ${reward.name}`])]
    });
  };

  const addWater = (amount: number) => {
    let next = {
      ...data,
      coins: (data.coins ?? 0) + 3,
      water: [...data.water, { id: crypto.randomUUID(), date: todayKey(), time: timeOnly(), amount }]
    };
    next = updateChecklist("water", true, next);
    next = addXp(next, waterToday + amount >= data.waterGoalMl && waterToday < data.waterGoalMl ? 45 : 10);
    commitData(next);
  };

  const registerWeight = (event: FormEvent) => {
    event.preventDefault();
    const entry: WeightEntry = { id: crypto.randomUUID(), date: todayKey(), weight: weightInput };
    let next = { ...data, currentWeight: weightInput, weights: [...data.weights, entry], coins: (data.coins ?? 0) + 10 };
    next = updateChecklist("weightRegistered", true, next);
    next = addXp(next, 25);
    commitData(next);
  };

  const planMeal = (event: FormEvent) => {
    event.preventDefault();
    const planned: PlannedMeal = { id: crypto.randomUUID(), name: plannedName || "Refeicao", plannedTime };
    commitData({ ...data, plannedMeals: [...data.plannedMeals, planned] });
  };

  const toggleChecklist = (key: keyof ChecklistState) => commitData(updateChecklist(key, !todayChecklist[key]));

  const handleLogin = async (event: FormEvent) => {
    event.preventDefault();
    const patient = await findPatient(loginEmail, loginPassword);
    if (!patient) {
      setLoginError("Email ou senha incorretos. Cadastre o paciente ou confira os dados.");
      return;
    }
    const localData = loadData(patient);
    const serverData = await loadServerData(patient.id);
    const nextData = serverData ? { ...localData, ...serverData, patientId: patient.id } : localData;
    saveSessionPatientId(patient.id);
    setCurrentPatient(patient);
    updateStoredPatient(patient);
    setData(nextData);
    setWeightInput(nextData.currentWeight);
    setOnboarding({
      currentWeight: nextData.currentWeight,
      targetWeight: nextData.targetWeight,
      objective: patient.objective ?? "lose",
      monthlyWeightGoal: patient.monthlyWeightGoal ?? 5,
      weeklyReward: patient.favoriteWeeklyReward ?? "Cinema",
      monthlyReward: patient.favoriteMonthlyReward ?? "Restaurante"
    });
    setShowOnboarding(!patient.firstAccessComplete);
    setLoginError("");
  };

  const handleLogout = () => {
    clearSessionPatientId();
    setCurrentPatient(null);
    setLoginPassword("Senha@123");
  };

  const handleRegister = async (event: FormEvent) => {
    event.preventDefault();
    try {
      const patient = await registerPatient(registerForm);
      const nextData = loadData(patient);
      await saveServerData(nextData, patient.id);
      saveSessionPatientId(patient.id);
      setPatientList(getAllPatients());
      setCurrentPatient(patient);
      setData(nextData);
      setWeightInput(nextData.currentWeight);
      setShowOnboarding(false);
      setLoginError("");
    } catch (error) {
      setLoginError(error instanceof Error ? error.message : "Nao foi possivel cadastrar o paciente.");
    }
  };

  const enterCreatedAccount = () => {
    if (!pendingPatient || !pendingData) return;
    saveSessionPatientId(pendingPatient.id);
    setCurrentPatient(pendingPatient);
    setData(pendingData);
    setWeightInput(pendingData.currentWeight);
    setShowOnboarding(true);
    setPendingPatient(null);
    setPendingData(null);
  };

  const handleRecover = (event: FormEvent) => {
    event.preventDefault();
    setRecoverySent(true);
  };

  const finishOnboarding = () => {
    if (!currentPatient) return;
    const updatedPatient: Patient = {
      ...currentPatient,
      currentWeight: onboarding.currentWeight,
      targetWeight: onboarding.targetWeight,
      objective: onboarding.objective,
      monthlyWeightGoal: onboarding.monthlyWeightGoal,
      favoriteWeeklyReward: onboarding.weeklyReward,
      favoriteMonthlyReward: onboarding.monthlyReward,
      firstAccessComplete: true
    };
    const nextData = {
      ...data,
      currentWeight: onboarding.currentWeight,
      targetWeight: onboarding.targetWeight,
      rewards: {
        ...data.rewards,
        weekly: onboarding.weeklyReward,
        monthly: onboarding.monthlyReward
      }
    };
    setCurrentPatient(updatedPatient);
    updateStoredPatient(updatedPatient);
    void syncPatientToServer(updatedPatient);
    void saveServerData(nextData, updatedPatient.id);
    setPatientList(getAllPatients());
    setData(nextData);
    setShowOnboarding(false);
  };

  const updateRegisterForm = <K extends keyof PatientForm>(key: K, value: PatientForm[K]) => {
    setRegisterForm((current) => ({ ...current, [key]: value }));
  };

  if (!currentPatient) {
    return (
      <LoginPage
        email={loginEmail}
        password={loginPassword}
        patients={patientList}
        registerForm={registerForm}
        mode={authMode}
        createStep={createStep}
        error={loginError}
        rememberMe={rememberMe}
        recoveryEmail={recoveryEmail}
        recoverySent={recoverySent}
        onModeChange={setAuthMode}
        onCreateStepChange={setCreateStep}
        onEmailChange={setLoginEmail}
        onPasswordChange={setLoginPassword}
        onRememberChange={setRememberMe}
        onRecoveryEmailChange={setRecoveryEmail}
        onSubmit={handleLogin}
        onRegister={handleRegister}
        onRecover={handleRecover}
        onRegisterChange={updateRegisterForm}
        onEnterCreated={enterCreatedAccount}
      />
    );
  }

  return (
    <main className={`app-canvas theme-${data.settings?.theme ?? "military"}`}>
      {showOnboarding ? (
        <OnboardingWizard
          step={onboardingStep}
          data={onboarding}
          onStepChange={setOnboardingStep}
          onChange={(next) => setOnboarding((current) => ({ ...current, ...next }))}
          onFinish={finishOnboarding}
        />
      ) : null}
      <aside className="side-nav">
        <Brand />
        <nav className="nav-stack">
          {navItems.map(([label, icon], index) => (
            <a className={index === 0 ? "nav-item active" : "nav-item"} href={`#${label.toLowerCase()}`} key={label}>
              <span>{icon}</span>
              {label}
            </a>
          ))}
        </nav>
      </aside>

      <div className="command-center">
        <header className="top-bar">
          <Brand compact />
          <div className="top-actions">
            <span className="patient-pill">{currentPatient.name}</span>
            <button className="wake-button" onClick={handleWake}>Acordei agora</button>
            <span className="status-dot">2</span>
            <button className="gear" onClick={handleLogout}>Sair</button>
          </div>
        </header>

        <section className="hero-panel" id="painel">
          <div className="clock-block">
            <h1>{formatTime(clock)}</h1>
            <p>{formatDateLong(clock)}</p>
          </div>
          <div className="hero-grid">
            <StatCard title="Peso atual" value={`${data.currentWeight.toFixed(1)} kg`} spark />
            <StatCard title="Meta 30 dias" value={`${dayGoal.toFixed(1)} kg`} caption={`${daysRemainingToGoal(data)} dias restantes`} progress={65} />
            <StatCard title="Peso perdido" value={`-${weightLost.toFixed(1)} kg`} caption="objetivo em andamento" spark />
          </div>
        </section>

        <div className="mode-switches">
          <button onClick={() => setFocusMode((current) => !current)}>{focusMode ? "Mostrar dashboard completo" : "Ativar modo foco"}</button>
          <button onClick={() => setSoundOn((current) => !current)}>{soundOn ? "Som ligado" : "Som desligado"}</button>
        </div>

        {focusMode ? (
          <section className="focus-panel">
            <h2>Missao de hoje</h2>
            <Metric label="Agua" value={`${waterToday} ml`} note={`restam ${Math.max(0, data.waterGoalMl - waterToday)} ml`} />
            <Metric label="Proxima refeicao" value={data.plannedMeals[0]?.name ?? plannedName} note={data.plannedMeals[0]?.plannedTime ?? plannedTime} />
            <Metric label="Peso atual" value={`${data.currentWeight.toFixed(1)} kg`} note={`${weightLost.toFixed(1)} kg perdidos`} />
            <Metric label="Recompensa" value={(data.shopRewards ?? []).find((reward) => !reward.claimed)?.name ?? data.rewards.weekly} note={nextReward(data)} />
            <button onClick={openRewardBox}>Abrir caixa ao cumprir meta</button>
          </section>
        ) : null}

        {!focusMode ? <>
        <section className="mission-console">
          <div>
            <span>Missao atual</span>
            <h2>{data.currentWeight.toFixed(1)} kg para {data.targetWeight.toFixed(1)} kg</h2>
            <p>Faltam {remainingKg.toFixed(1)} kg. Previsao: {predictedGoalDate}.</p>
          </div>
          <div className="console-grid">
            <Metric label="Progresso" value={`${progressPercent}%`} note="rumo a meta final" />
            <Metric label="Patente" value={rank.name} note={`${data.xp}/${rank.nextXp} XP`} />
            <Metric label="IMC" value={bmi.toFixed(1)} note={bmiLabel(bmi)} />
            <Metric label="Seq." value={`${data.streak} dias`} note="medalhas aos 3, 7, 30 e 100" />
          </div>
          {safetyWarnings.length ? (
            <div className="safety-alerts">
              {safetyWarnings.map((warning) => <p key={warning}>{warning}</p>)}
            </div>
          ) : null}
        </section>

        <section className="base-grid">
          <Panel title="Central de comando">
            <div className="command-card">
              <span>OPERADOR: {currentPatient.nickname || currentPatient.name}</span>
              <span>PATENTE: {rank.name}</span>
              <span>PESO: {data.currentWeight.toFixed(1)} kg</span>
              <span>META FINAL: {data.targetWeight.toFixed(1)} kg</span>
              <span>AGUA: {waterToday}/{data.waterGoalMl} ml</span>
              <span>XP: {data.xp}/{rank.nextXp}</span>
              <span>SEQUENCIA: {data.streak} dias</span>
              <span>PROXIMA RECOMPENSA: {(data.shopRewards ?? []).find((reward) => !reward.claimed)?.name ?? "Big Mac"}</span>
              <span>MISSAO DE HOJE: {daily}%</span>
            </div>
          </Panel>

          <Panel title="Modo offline">
            <div className="widget-grid">
              <span><b>Status</b>{isOnline ? "Online" : "Offline"}</span>
              <span><b>Sincronizacao</b>{isOnline ? "Pronta" : `${(data.syncQueue ?? []).length} item(ns) aguardando`}</span>
              <span><b>PWA</b>Funciona sem internet e sincroniza ao voltar.</span>
            </div>
          </Panel>

          <Panel title="Minha base">
            <div className="base-card">
              <span><b>Operador</b>{currentPatient.nickname || currentPatient.name}</span>
              <span><b>Patente</b>{rank.name}</span>
              <span><b>Peso atual</b>{data.currentWeight.toFixed(1)} kg</span>
              <span><b>Peso meta</b>{data.targetWeight.toFixed(1)} kg</span>
              <span><b>Dias de missao</b>{appStats.daysUsing}</span>
              <span><b>XP</b>{data.xp}/{rank.nextXp}</span>
              <span><b>Proxima promocao</b>{rank.nextName}</span>
              <span><b>Proxima recompensa</b>{(data.shopRewards ?? []).find((reward) => !reward.claimed)?.name ?? "Escolha uma recompensa"}</span>
            </div>
          </Panel>

          <Panel title="Quartel-General HQ">
            <div className="hq-card">
              <span>OPERADOR: {currentPatient.nickname || currentPatient.name}</span>
              <span>PATENTE: {rank.name}</span>
              <span>PESO: {data.currentWeight.toFixed(1)} kg</span>
              <span>META FINAL: {data.targetWeight.toFixed(1)} kg</span>
              <span>MISSÃO ATUAL: -{Math.min(15, weightLost).toFixed(1)} kg</span>
              <span>XP: {data.xp}/{rank.nextXp}</span>
              <span>SEQUÊNCIA: {data.streak} dias</span>
              <span>ÁGUA: {waterToday}/{data.waterGoalMl} ml</span>
              <span>PRÓXIMA RECOMPENSA: {(data.shopRewards ?? []).find((reward) => !reward.claimed)?.name ?? "Cadastrar"}</span>
              <span>PRÓXIMA PATENTE: {rank.nextName}</span>
            </div>
          </Panel>

          <Panel title="Seu avatar">
            <div className="avatar-card">
              <div className={`avatar-body stage-${avatar.stage}`}>
                <span>{avatar.initials}</span>
              </div>
              <div>
                <strong>{avatar.uniform}</strong>
                <p>{avatar.description}</p>
                <small>Itens: {avatar.items.join(", ")}</small>
              </div>
            </div>
          </Panel>

          <Panel title="IA Coach">
            <div className="coach-list">
              {coachMessages.map((message) => <p key={message}>{message}</p>)}
            </div>
            <div className="mood-row">
              <strong>Como voce esta hoje?</strong>
              {moodOptions.map((mood) => <button className={(data.moodByDate ?? {})[todayKey()] === mood ? "selected" : ""} key={mood} onClick={() => setMood(mood)}>{mood}</button>)}
            </div>
          </Panel>

          <Panel title="Metas inteligentes">
            <Metric label="Semanal" value={`${smartGoals.weekly.toFixed(1)} kg`} note="recalculada pelo ritmo" />
            <Metric label="Mensal" value={`${smartGoals.monthly.toFixed(1)} kg`} note="meta dinamica" />
            <Metric label="Anual" value={`${smartGoals.yearly.toFixed(1)} kg`} note="projecao segura" />
          </Panel>

          <Panel title="Previsoes">
            <Metric label="30 dias" value={`${predictions.day30.toFixed(1)} kg`} note="se mantiver o ritmo" />
            <Metric label="60 dias" value={`${predictions.day60.toFixed(1)} kg`} note="se mantiver o ritmo" />
            <Metric label="90 dias" value={`${predictions.day90.toFixed(1)} kg`} note="se mantiver o ritmo" />
            <Metric label="Meta final" value={predictedGoalDate} note="data estimada" />
          </Panel>

          <Panel title="Mapa de campanha">
            <div className="campaign-map">
              {campaign.map((step) => <span className={step.done ? "done" : ""} key={step.title}><b>{step.title}</b><small>{step.weight} kg</small></span>)}
            </div>
          </Panel>

          <Panel title="Central de inteligencia">
            <div className="coach-list">
              {intelligence.map((item) => <p key={item}>{item}</p>)}
            </div>
          </Panel>

          <Panel title="Memorias da jornada">
            <div className="vault-grid">
              {journeyMemories.map((memory) => <span key={memory.label}><b>{memory.label}</b>{memory.value}</span>)}
            </div>
          </Panel>

          <Panel title="Sistema de habitos">
            <form className="routine-form" onSubmit={addHabit}>
              <label>Novo habito<input value={habitName} placeholder="Ex.: caminhar 10 minutos" onChange={(event) => setHabitName(event.target.value)} /></label>
              <ActionButton type="submit">Criar habito</ActionButton>
            </form>
            <HabitList habits={data.habits ?? []} onToggle={toggleHabit} />
          </Panel>

          <Panel title="Modo viagem">
            <form className="routine-form" onSubmit={saveTravelMode}>
              <label>Local<input value={travelLocation} placeholder="Cidade ou viagem" onChange={(event) => setTravelLocation(event.target.value)} /></label>
              <label>Ajuste de horas<input type="number" value={travelShift} onChange={(event) => setTravelShift(Number(event.target.value))} /></label>
              <ActionButton type="submit">Ativar viagem</ActionButton>
            </form>
            <p className="panel-copy">{data.travelMode?.active ? `Sequencia preservada em ${data.travelMode.location || "viagem"} com ajuste de ${data.travelMode.timeShift}h.` : "Ative quando viajar para adaptar lembretes."}</p>
            {data.travelMode?.active ? <button className="claim-button" onClick={disableTravelMode}>Encerrar viagem</button> : null}
          </Panel>

          <Panel title="Widgets">
            <div className="widget-grid">
              <span><b>Pequeno</b>{widgets.small}</span>
              <span><b>Medio</b>{widgets.medium}</span>
              <span><b>Grande</b>{widgets.large}</span>
            </div>
          </Panel>

          <Panel title="Central de dados">
            <Metric label="Peso medio mensal" value={`${dataCenter.monthlyWeight.toFixed(1)} kg`} note="media local" />
            <Metric label="Agua media diaria" value={`${dataCenter.avgWater.toFixed(0)} ml`} note="media" />
            <Metric label="Taxa de cumprimento" value={`${dataCenter.compliance}%`} note="metas" />
            <Metric label="Melhor semana" value={`${dataCenter.bestWeek}%`} note="recorde" />
          </Panel>

          <Panel title="Temporadas">
            <div className="season-list">
              {(data.seasons ?? []).map((season) => {
                const progress = Math.min(100, Math.round((weightLost / season.targetLoss) * 100));
                return <div key={season.id}><strong>{season.name}</strong><ProgressBar value={progress} /><small>{season.reward}</small></div>;
              })}
            </div>
          </Panel>

          <Panel title="Simulador de metas">
            <form className="routine-form" onSubmit={(event) => event.preventDefault()}>
              <label>Se eu perder kg por mes<input type="number" min="0.1" step="0.1" value={simLoss} onChange={(event) => setSimLoss(Number(event.target.value))} /></label>
            </form>
            <p className="ai-message">Previsao da meta: {simulatorDate}</p>
          </Panel>

          <Panel title="Laboratorio de simulacoes">
            <div className="vault-grid">
              {[5, 8, 10].map((kg) => <span key={kg}>Se perder {kg} kg/mes: {simulateGoalDate(data.currentWeight, data.targetWeight, kg)}</span>)}
            </div>
          </Panel>

          <Panel title="IA de planejamento">
            <div className="reflection-grid">
              {["Descansar", "Trabalhar", "Sair", "Comer fora", "Ficar em casa"].map((plan) => <button className={todayPlan === plan ? "selected" : ""} key={plan} onClick={() => setTodayPlan(plan)}>{plan}</button>)}
            </div>
            <p className="ai-message">{planAdvice}</p>
          </Panel>

          <Panel title="Sistema de previsao">
            <pre className="prediction-box">{predictionText}</pre>
          </Panel>

          <Panel title="Temas">
            <div className="theme-grid">
              {(["military", "future", "corporate", "minimal", "blackout"] as const).map((theme) => <button className={(data.settings?.theme ?? "military") === theme ? "selected" : ""} key={theme} onClick={() => updateTheme(theme)}>{theme}</button>)}
            </div>
          </Panel>
        </section>

        <section className="dashboard-grid">
          <Panel className="progress-panel" title="Progresso">
            <CircleProgress label="Meta diaria" value={daily} />
            <CircleProgress label="Meta semanal" value={weekly} />
            <CircleProgress label="Meta mensal" value={monthly} />
          </Panel>

          <Panel className="water-panel" title="Agua hoje" id="agua">
            <div>
              <strong>{waterToday.toLocaleString("pt-BR")} ml</strong>
              <span>de {data.waterGoalMl.toLocaleString("pt-BR")} ml</span>
              <ProgressBar value={waterPercent} />
              <div className="button-row">
                {[200, 300, 500].map((amount) => (
                  <button key={amount} className="mini-button" onClick={() => addWater(amount)}>+ {amount} ml</button>
                ))}
              </div>
            </div>
            <div className="cup" aria-hidden="true"><span style={{ height: `${waterPercent}%` }} /></div>
          </Panel>

          <Panel title="Proxima recompensa">
            <p className="panel-copy">{nextReward(data)}</p>
            <ProgressBar value={weekly} />
            <div className="gift-box">BOX</div>
          </Panel>

          <Panel title="Streak">
            <div className="streak-card">
              <span className="flame">F</span>
              <strong>{data.streak} dias</strong>
              <small>Melhor: 12 dias</small>
            </div>
          </Panel>

          <Panel title="Checklist diario">
            <div className="compact-checklist">
              {(Object.keys(checklistLabels) as Array<keyof ChecklistState>).map((key) => (
                <button key={key} onClick={() => toggleChecklist(key)}>
                  <span className={todayChecklist[key] ? "tick on" : "tick"} />
                  {checklistLabels[key]}
                </button>
              ))}
            </div>
          </Panel>

          <Panel className="summary-panel" title="Resumo do dia">
            <Metric label="Refeicoes" value={`${data.meals.filter((meal) => meal.date === todayKey()).length}`} note="de 3" />
            <Metric label="Gramas" value={`${1000 - remainingMealGrams} g`} note="de 1.000 g" />
            <Metric label="Agua" value={`${waterToday} ml`} note={`de ${data.waterGoalMl} ml`} />
            <Metric label="XP" value={`${data.xp}`} note={`nivel ${level}`} />
          </Panel>

          <Panel className="chart-panel" title="Evolucao do peso" id="peso">
            <WeightChart entries={latestWeights} />
          </Panel>

          <Panel title="Dashboard tatico">
            <Metric label="Kg faltantes" value={`${remainingKg.toFixed(1)} kg`} note="ate a meta final" />
            <Metric label="Media semanal" value={`${weeklyAverageLoss.toFixed(1)} kg`} note="perda estimada" />
            <Metric label="Media mensal" value={`${monthlyAverageLoss.toFixed(1)} kg`} note="perda estimada" />
            <Metric label="Chegada aos 100 kg" value={predictedGoalDate} note="previsao local" />
          </Panel>

          <Panel title="Calendario">
            <CalendarGrid data={data} />
          </Panel>

          <Panel title="Patentes e medalhas">
            <div className="rank-list">
              {rankTable.map(([name, xp]) => <span className={data.xp >= xp ? "earned" : ""} key={name}>{name}<b>{xp} XP</b></span>)}
            </div>
            <div className="medal-row">
              {[3, 7, 15, 30, 100].map((days) => <span className={data.streak >= days ? "earned" : ""} key={days}>{days} dias</span>)}
            </div>
          </Panel>
        </section>

        <section className="mobile-flow" id="refeicoes">
          <SectionTitle title="Fluxo: foto do prato" />
          <div className="flow-grid">
            <FlowPhone title="1 Tirar foto">
              <div className="camera-card">
                {photo ? <img src={photo} alt="Preview do prato" /> : <div className="plate-placeholder">PRATO</div>}
                <div className="camera-actions">
                  <label>Abrir camera<input type="file" accept="image/*" capture="environment" onChange={handlePhoto} /></label>
                  <label>Enviar galeria<input type="file" accept="image/*" onChange={handlePhoto} /></label>
                </div>
              </div>
            </FlowPhone>

            <FlowPhone title="2 Preview e estimativa">
              <div className="estimate-card">
                {photo ? <img src={photo} alt="Preview estimado" /> : <div className="plate-placeholder small">FOTO</div>}
                <p>Estimativa de peso</p>
                <strong>{mealGrams} g</strong>
                <div className="ai-foods">
                  {mealAnalysis.foods.map((food) => <span key={food}>{food}</span>)}
                </div>
                <small>{mealAnalysis.calories} kcal | P {mealAnalysis.protein} g | C {mealAnalysis.carbs} g | G {mealAnalysis.fat} g</small>
                <p className="ai-message">{mealAnalysis.message}</p>
                <small>Estimativa aproximada. Para maior precisao, use balanca de cozinha.</small>
              </div>
            </FlowPhone>

            <FlowPhone title="3 Editar itens">
              <form className="edit-form" onSubmit={handleMeal}>
                <label>Nome<input value={mealName} onChange={(event) => {
                  setMealName(event.target.value);
                  setMealAnalysis(analyzeMeal(mealGrams, event.target.value));
                }} /></label>
                <label>Gramas<input type="number" min="1" value={mealGrams} onChange={(event) => handleMealGramsChange(Number(event.target.value))} /></label>
                <label>Observacao<textarea value={mealNote} onChange={(event) => setMealNote(event.target.value)} /></label>
                <button>Salvar refeicao</button>
              </form>
            </FlowPhone>

            <FlowPhone title="4 Refeicao registrada">
              <div className="success-card">
                <div className="success-mark">OK</div>
                <p>Refeicao registrada com sucesso</p>
                <strong>{mealName}</strong>
                <span>{mealGrams} g</span>
              </div>
            </FlowPhone>
          </div>
        </section>

        <section className="lower-grid">
          <Panel title="Dados do paciente">
            <div className="patient-data">
              <span><b>Nome</b>{currentPatient.name}</span>
              <span><b>Email</b>{currentPatient.email}</span>
              <span><b>CPF</b>{currentPatient.cpf ? currentPatient.cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4") : "Nao informado"}</span>
              <span><b>Idade</b>{currentPatient.age} anos</span>
              <span><b>Altura</b>{currentPatient.heightCm} cm</span>
              <span><b>Profissional</b>{currentPatient.doctor}</span>
              <span><b>Plano</b>{currentPatient.plan}</span>
              <span><b>Observacao</b>{currentPatient.notes}</span>
            </div>
          </Panel>

          <Panel title="Perfil de saude">
            <form className="routine-form" onSubmit={saveHealthProfile}>
              <label>Medicamentos em uso<input value={healthDraft.medicines} placeholder="Ex.: Mounjaro, vitaminas..." onChange={(event) => setHealthDraft((current) => ({ ...current, medicines: event.target.value }))} /></label>
              <label>Alergias<input value={healthDraft.allergies} placeholder="Ex.: lactose, amendoim..." onChange={(event) => setHealthDraft((current) => ({ ...current, allergies: event.target.value }))} /></label>
              <label>Condicoes de saude<input value={healthDraft.conditions} placeholder="Opcional" onChange={(event) => setHealthDraft((current) => ({ ...current, conditions: event.target.value }))} /></label>
              <ActionButton type="submit">Salvar perfil</ActionButton>
            </form>
          </Panel>

          <Panel title="Check-up">
            <form className="routine-form" onSubmit={saveCheckup}>
              <label>Pressao arterial<input value={checkup.bloodPressure} placeholder="120/80" onChange={(event) => setCheckup((current) => ({ ...current, bloodPressure: event.target.value }))} /></label>
              <label>Glicemia<input type="number" value={checkup.glucose} onChange={(event) => setCheckup((current) => ({ ...current, glucose: Number(event.target.value) }))} /></label>
              <label>Frequencia cardiaca<input type="number" value={checkup.heartRate} onChange={(event) => setCheckup((current) => ({ ...current, heartRate: Number(event.target.value) }))} /></label>
              <label>Historico de exames<input value={checkup.examNote} onChange={(event) => setCheckup((current) => ({ ...current, examNote: event.target.value }))} /></label>
              <ActionButton type="submit">Salvar check-up</ActionButton>
            </form>
          </Panel>

          <Panel title="Integracao com relogios">
            <form className="routine-form" onSubmit={saveWatch}>
              <label>Fonte<select value={watchDraft.source} onChange={(event) => setWatchDraft((current) => ({ ...current, source: event.target.value as "Apple Watch" | "Wear OS" | "Manual" }))}>
                <option>Manual</option>
                <option>Apple Watch</option>
                <option>Wear OS</option>
              </select></label>
              <label>Passos<input type="number" value={watchDraft.steps} onChange={(event) => setWatchDraft((current) => ({ ...current, steps: Number(event.target.value) }))} /></label>
              <label>Frequencia cardiaca<input type="number" value={watchDraft.heartRate} onChange={(event) => setWatchDraft((current) => ({ ...current, heartRate: Number(event.target.value) }))} /></label>
              <label>Exercicios (min)<input type="number" value={watchDraft.exerciseMinutes} onChange={(event) => setWatchDraft((current) => ({ ...current, exerciseMinutes: Number(event.target.value) }))} /></label>
              <ActionButton type="submit">Salvar relogio</ActionButton>
            </form>
          </Panel>

          <Panel title="Sono">
            <form className="routine-form" onSubmit={saveSleep}>
              <label>Hora que dormiu<input type="time" value={sleepDraft.sleptAt} onChange={(event) => setSleepDraft((current) => ({ ...current, sleptAt: event.target.value }))} /></label>
              <label>Hora que acordou<input type="time" value={sleepDraft.wokeAt} onChange={(event) => setSleepDraft((current) => ({ ...current, wokeAt: event.target.value }))} /></label>
              <label>Qualidade<select value={sleepDraft.quality} onChange={(event) => setSleepDraft((current) => ({ ...current, quality: event.target.value }))}>
                <option>Muito boa</option><option>Boa</option><option>Normal</option><option>Ruim</option>
              </select></label>
              <ActionButton type="submit">Salvar sono</ActionButton>
            </form>
            <Metric label="Media sono" value={`${sleepStats.average.toFixed(1)} h`} note={sleepStats.quality} />
          </Panel>

          <Panel title="Bem-estar">
            <div className="mood-row">
              {moodOptions.map((mood) => <button className={(data.moodByDate ?? {})[todayKey()] === mood ? "selected" : ""} key={mood} onClick={() => setMood(mood)}>{mood}</button>)}
            </div>
            <Metric label="Humor mais comum" value={moodStats.common} note={`${moodStats.total} registro(s)`} />
          </Panel>

          <Panel title="Economia">
            <form className="routine-form" onSubmit={saveEconomy}>
              <label>Lanches recompensa<input type="number" value={economyDraft.snackRewards} onChange={(event) => setEconomyDraft((current) => ({ ...current, snackRewards: Number(event.target.value) }))} /></label>
              <label>Quanto gastou<input type="number" value={economyDraft.snackSpent} onChange={(event) => setEconomyDraft((current) => ({ ...current, snackSpent: Number(event.target.value) }))} /></label>
              <label>Economia cozinhando<input type="number" value={economyDraft.homeSavings} onChange={(event) => setEconomyDraft((current) => ({ ...current, homeSavings: Number(event.target.value) }))} /></label>
              <ActionButton type="submit">Salvar economia</ActionButton>
            </form>
          </Panel>

          <Panel title="Central de estatisticas">
            <Metric label="Dias usando" value={`${appStats.daysUsing}`} note="desde o inicio" />
            <Metric label="Refeicoes" value={`${appStats.meals}`} note="registradas" />
            <Metric label="Agua" value={`${appStats.waterLiters.toFixed(1)} L`} note="total consumido" />
            <Metric label="Peso perdido" value={`${weightLost.toFixed(1)} kg`} note="progresso" />
            <Metric label="Maior sequencia" value={`${appStats.bestStreak} dias`} note="recorde" />
            <Metric label="Recompensas" value={`${appStats.rewards}`} note="desbloqueadas" />
          </Panel>

          <Panel title="Objetivos personalizados">
            <form className="routine-form" onSubmit={addObjective}>
              <label>Novo objetivo<input value={objectiveText} placeholder="Ex.: entrar em uma roupa especifica" onChange={(event) => setObjectiveText(event.target.value)} /></label>
              <ActionButton type="submit">Criar missao</ActionButton>
            </form>
            <div className="habit-list">
              {(data.objectives ?? []).map((objective) => <button className={objective.done ? "done" : ""} key={objective.id} onClick={() => toggleObjective(objective.id)}>{objective.text}</button>)}
            </div>
          </Panel>

          <Panel title="Linha do tempo">
            <div className="timeline-list">
              {timeline.map((item) => <span className={item.done ? "done" : ""} key={item.label}><b>{item.date}</b>{item.label}</span>)}
            </div>
          </Panel>

          <Panel title="Recordes pessoais">
            <Metric label="Maior sequencia" value={`${records.longestStreak} dias`} note="recorde" />
            <Metric label="Mais agua" value={`${records.maxWaterMl} ml`} note="em um dia" />
            <Metric label="Maior perda mensal" value={`${records.maxMonthlyLoss.toFixed(1)} kg`} note="saudavel" />
            <Metric label="Mais refeicoes" value={`${records.maxMealsDay}`} note="registradas em um dia" />
          </Panel>

          <Panel title="Capsula do tempo">
            <form className="routine-form" onSubmit={saveTimeCapsule}>
              <label>Por que quero emagrecer?<textarea value={timeCapsuleText} onChange={(event) => setTimeCapsuleText(event.target.value)} /></label>
              <ActionButton type="submit">Guardar mensagem</ActionButton>
            </form>
            {legacy.unlocked && data.timeCapsule ? <p className="ai-message">{data.timeCapsule}</p> : <p className="panel-copy">A mensagem reaparece quando a missao final for concluida.</p>}
          </Panel>

          <Panel title="Conquistas">
            <div className="badge-grid">
              {achievements.map((achievement) => <span className={achievement.done ? "earned" : ""} key={achievement.name}>{achievement.name}</span>)}
            </div>
          </Panel>

          <Panel title="Desafios">
            <div className="special-missions">
              {challengeList.map((challenge) => <div key={challenge.name}><strong>{challenge.name}</strong><ProgressBar value={challenge.progress} /><small>{challenge.text}</small></div>)}
            </div>
          </Panel>

          <Panel title="Colecionaveis">
            <div className="badge-grid">
              {collectibles.map((item) => <span className={item.done ? "earned" : ""} key={item.name}>{item.name}</span>)}
            </div>
          </Panel>

          <Panel title="Analytics">
            <Metric label="Peso semanal" value={`${analytics.weeklyWeight.toFixed(1)} kg`} note="media" />
            <Metric label="Agua media" value={`${analytics.avgWater.toFixed(0)} ml`} note="diaria" />
            <Metric label="Refeicoes media" value={`${analytics.avgMeals.toFixed(1)}`} note="por dia" />
            <Metric label="Horario comum" value={`${analytics.commonHour}h`} note="refeicoes" />
            <Metric label="Cumprimento" value={`${analytics.compliance}%`} note="metas" />
          </Panel>

          <Panel title="Central de conhecimento">
            <div className="knowledge-list">
              {knowledgeArticles().map((article) => <details key={article.title}><summary>{article.title}</summary><p>{article.text}</p></details>)}
            </div>
          </Panel>

          <Panel title="Missoes especiais">
            <div className="special-missions">
              {specialMissions.map((mission) => (
                <div key={mission.name}>
                  <strong>{mission.name}</strong>
                  <ProgressBar value={mission.progress} />
                  <small>{mission.text}</small>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Distintivos">
            <div className="badge-grid">
              {badgesFor(data).map((badge) => <span className={badge.done ? "earned" : ""} key={badge.name}>{badge.name}</span>)}
            </div>
          </Panel>

          <Panel title="Titulos especiais">
            <div className="badge-grid">
              {specialTitles.map((title) => <span className={title.done ? "earned" : ""} key={title.name}>{title.name}</span>)}
            </div>
          </Panel>

          <Panel title="Sala de trofeus">
            <div className="trophy-grid">
              {trophyItems.map((item) => <span className={item.done ? "earned" : ""} key={item.name}>{item.name}<b>{item.detail}</b></span>)}
            </div>
          </Panel>

          <Panel title="Mapa da jornada">
            <div className="journey-map">
              {journey.map((item) => (
                <span className={item.done ? "done" : ""} key={item.weight}>
                  <b>{item.title}</b>
                  <small>{item.weight} kg</small>
                </span>
              ))}
            </div>
          </Panel>

          <Panel title="Mapa interativo">
            <div className="interactive-map">
              {interactiveMap.map((step) => <span className={step.done ? "done" : ""} key={step.name}><b>{step.name}</b>{step.weight} kg</span>)}
            </div>
          </Panel>

          <Panel title="Mapa mundial">
            <Metric label="Distancia" value={`${worldMap.km} km`} note="1 kg = 10 km" />
            <Metric label="Cidade alcancada" value={worldMap.city} note="marco desbloqueado" />
            <ProgressBar value={worldMap.progress} />
          </Panel>

          <Panel title="Rotina personalizada" id="rotina">
            <div className="routine-clock">
              <span>Voce acordou as</span>
              <strong>{data.wakeTime ?? "--:--"}</strong>
            </div>
            <form className="routine-form" onSubmit={planMeal}>
              <label>Que horas vou dormir?<input type="time" value={data.sleepTime} onChange={(event) => commitData({ ...data, sleepTime: event.target.value })} /></label>
              <label>Nome da refeicao<input value={plannedName} onChange={(event) => setPlannedName(event.target.value)} /></label>
              <label>Horario planejado<input type="time" value={plannedTime} onChange={(event) => setPlannedTime(event.target.value)} /></label>
              <ActionButton type="submit">Adicionar refeicao</ActionButton>
            </form>
            <div className="planned-list">
              {(data.plannedMeals.length ? data.plannedMeals : [{ id: "a", name: "Almoco", plannedTime: "13:00" }, { id: "b", name: "Janta", plannedTime: "19:30" }]).slice(-3).map((meal) => (
                <span key={meal.id}>{meal.name}<b>{meal.plannedTime}</b></span>
              ))}
            </div>
          </Panel>

          <Panel title="Historico" id="historico">
            <div className="history-list">
              {(latestMeals.length ? latestMeals : [{ id: "sample", name: "Almoco", time: "13:20", grams: 420, date: todayKey(), note: "", withinGoal: true }]).map((meal) => (
                <div className="history-row" key={meal.id}>
                  <span className="meal-thumb">{meal.photo ? <img src={meal.photo} alt="" /> : "MP"}</span>
                  <div><strong>{meal.name}</strong><small>{meal.time} - {meal.grams} g - {meal.calories ?? 0} kcal</small></div>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Scanner de alimentos">
            <form className="routine-form" onSubmit={scanBarcode}>
              <label>Codigo de barras<input value={barcode} inputMode="numeric" placeholder="7890000000000" onChange={(event) => setBarcode(event.target.value)} /></label>
              <label>Buscar alimento manualmente<input value={manualFood} placeholder="Ex.: frango, arroz, pizza" onChange={(event) => setManualFood(event.target.value)} /></label>
              <ActionButton type="submit">Buscar nutricao</ActionButton>
            </form>
            <div className="history-list">
              {(data.barcodeItems ?? []).slice(-3).reverse().map((item) => (
                <div className="history-row" key={item.id}>
                  <span className="meal-thumb">BAR</span>
                  <div><strong>{item.name}</strong><small>{item.calories} kcal | P {item.protein} g | C {item.carbs} g | G {item.fat} g</small></div>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Perfil & missoes" id="missoes">
            <div className="profile-head">
              <div className="avatar">G</div>
              <div><strong>{rank.name}</strong><span>Nivel {level}</span></div>
            </div>
            <ProgressBar value={(xpInLevel / 300) * 100} />
            <Mission done={waterToday >= data.waterGoalMl} text="Beber 2.300 ml de agua" />
            <Mission done={todayChecklist.mealRegistered} text="Registrar todas as refeicoes" />
            <Mission done={weekly >= 80} text="Cumprir 80% da semana" />
            <div className="profile-actions">
              <button>Editar perfil</button>
              <button>Alterar senha</button>
              <button onClick={handleLogout}>Sair da conta</button>
            </div>
          </Panel>

          <Panel title="Loja de recompensas">
            <form className="routine-form reward-form" onSubmit={addShopReward}>
              <label>Nova recompensa<input value={rewardName} placeholder="Ex.: restaurante" onChange={(event) => setRewardName(event.target.value)} /></label>
              <label>Custo em pontos<input type="number" min="1" value={rewardCost} onChange={(event) => setRewardCost(Number(event.target.value))} /></label>
              <ActionButton type="submit">Cadastrar recompensa</ActionButton>
            </form>
            <div className="shop-list">
              {(data.shopRewards ?? []).map((reward) => (
                <button key={reward.id} disabled={reward.claimed || data.xp < reward.cost} onClick={() => claimShopReward(reward.id)}>
                  <strong>{reward.name}</strong>
                  <span>{reward.claimed ? "Resgatado" : `${reward.cost} pontos`}</span>
                </button>
              ))}
            </div>
          </Panel>

          <Panel title="Seguranca e nuvem">
            <form className="routine-form" onSubmit={registerSymptom}>
              <div className="symptom-grid">
                {mounjaroSymptoms.map((symptom) => (
                  <label key={symptom}>
                    <input
                      type="checkbox"
                      checked={selectedSymptoms.includes(symptom)}
                      onChange={(event) => setSelectedSymptoms((current) => event.target.checked ? [...current, symptom] : current.filter((item) => item !== symptom))}
                    />
                    {symptom}
                  </label>
                ))}
              </div>
              <label>Sintoma extra<input value={symptomText} placeholder="Descreva apenas se acontecer" onChange={(event) => setSymptomText(event.target.value)} /></label>
              <label className="check-line"><input type="checkbox" checked={strongSymptoms} onChange={(event) => setStrongSymptoms(event.target.checked)} /> Sintomas fortes</label>
              {strongSymptoms ? <p className="urgent-alert">Pare e procure orientacao medica.</p> : null}
              <ActionButton type="submit">Registrar alerta</ActionButton>
            </form>
            <div className="cloud-grid">
              <span>Email ativo</span>
              <span>Google preparado</span>
              <span>Apple preparado</span>
              <span>Backup local automatico</span>
              <span>Sincronizacao futura</span>
            </div>
          </Panel>

          <Panel title="Foto antes/depois">
            <div className="body-photo-grid">
              {(data.bodyPhotos ?? []).slice(-2).map((item) => (
                <figure key={item.id}>
                  <img src={item.image} alt={item.note} />
                  <figcaption>{item.date} - {item.note}</figcaption>
                </figure>
              ))}
              {!(data.bodyPhotos ?? []).length ? <p className="panel-copy">Registre uma foto corporal semanal para criar sua linha do tempo.</p> : null}
            </div>
            <form className="routine-form" onSubmit={(event) => event.preventDefault()}>
              <label>Observacao<input value={bodyPhotoNote} placeholder="Semana 1, frente, lado..." onChange={(event) => setBodyPhotoNote(event.target.value)} /></label>
              <label>Angulo<select value={bodyPhotoAngle} onChange={(event) => setBodyPhotoAngle(event.target.value as "front" | "side" | "back")}>
                <option value="front">Frontal</option>
                <option value="side">Lateral</option>
                <option value="back">Traseira</option>
              </select></label>
              <label className="file-action">Abrir camera corporal<input type="file" accept="image/*" capture="environment" onChange={handleBodyPhoto} /></label>
              <label className="file-action">Enviar foto corporal<input type="file" accept="image/*" onChange={handleBodyPhoto} /></label>
            </form>
          </Panel>

          <Panel title="Scanner corporal">
            <div className="body-scan-grid">
              {(["front", "side", "back"] as const).map((angle) => {
                const latest = (data.bodyPhotos ?? []).filter((photo) => photo.angle === angle).slice(-1)[0];
                return <figure key={angle}>{latest ? <img src={latest.image} alt={angle} /> : <div>Sem foto</div>}<figcaption>{angle}</figcaption></figure>;
              })}
            </div>
            <p className="panel-copy">Use fotos frontal, lateral e traseira para comparar mensalmente.</p>
          </Panel>

          <Panel title="Medidas corporais">
            <form className="measure-grid" onSubmit={saveBodyMeasure}>
              {([
                ["waist", "Barriga/cintura"],
                ["chest", "Peito"],
                ["arm", "Braco"],
                ["thigh", "Coxa"],
                ["neck", "Pescoco"]
              ] as const).map(([key, label]) => (
                <label key={key}>{label}<input type="number" min="0" step="0.1" value={bodyMeasure[key]} onChange={(event) => setBodyMeasure((current) => ({ ...current, [key]: Number(event.target.value) }))} /></label>
              ))}
              <ActionButton type="submit">Salvar medidas</ActionButton>
            </form>
            <MeasureBars entries={data.bodyMeasures ?? []} />
          </Panel>

          <Panel title="Modo mercado">
            <form className="routine-form" onSubmit={addMarketItem}>
              <label>Item<input value={marketName} placeholder="Ex.: ovos, verdura, doce..." onChange={(event) => setMarketName(event.target.value)} /></label>
              <label>Tipo<select value={marketType} onChange={(event) => setMarketType(event.target.value as "shopping" | "favorite" | "blocked")}>
                <option value="shopping">Lista de compras</option>
                <option value="favorite">Favorito</option>
                <option value="blocked">Proibido por mim</option>
              </select></label>
              <ActionButton type="submit">Adicionar</ActionButton>
            </form>
            <MarketList items={data.marketItems ?? []} onToggle={toggleMarketItem} />
          </Panel>

          <Panel title="Modo emergencia">
            <button className="emergency-button" onClick={() => setEmergencyOpen((current) => !current)}>Estou passando mal</button>
            {emergencyOpen ? (
              <div className="emergency-list">
                <span>Beber agua em pequenos goles.</span>
                <span>Sentar ou deitar com seguranca.</span>
                <span>Avisar alguem proximo.</span>
                <span>Procurar atendimento se piorar.</span>
              </div>
            ) : null}
          </Panel>

          <Panel title="Relatorio e lembretes">
            <div className="profile-actions">
              <button onClick={generatePdfReport}>Gerar PDF</button>
              <button onClick={enableNotifications}>Ativar lembretes</button>
            </div>
            <p className="panel-copy">{notificationStatus}</p>
            <div className="cloud-grid">
              <span>Beber agua</span>
              <span>Registrar refeicao</span>
              <span>Registrar peso</span>
              <span>Tirar foto</span>
              <span>Dormir</span>
            </div>
          </Panel>

          <Panel title="Ranking pessoal">
            <Metric label="Melhor semana" value={`${personalRanking.bestWeek}%`} note="voce contra voce" />
            <Metric label="Melhor mes" value={`${personalRanking.bestMonth}%`} note="constancia mensal" />
            <Metric label="Maior sequencia" value={`${personalRanking.bestStreak} dias`} note="recorde pessoal" />
            <Metric label="Maior perda saudavel" value={`${personalRanking.healthyLoss.toFixed(1)} kg`} note="sem extremos" />
          </Panel>

          <Panel title="Modo sem culpa">
            <p className="no-guilt">{latestMeal && !latestMeal.withinGoal ? "Falhou uma refeicao, nao falhou o plano. Volte na proxima." : "Plano em andamento. Constancia vence perfeicao."}</p>
          </Panel>

          <Panel title="Modo reflexao">
            <p className="panel-copy">O que foi mais dificil hoje?</p>
            <div className="reflection-grid">
              {reflectionOptions.map((option) => <button className={(data.reflectionByDate ?? {})[todayKey()] === option ? "selected" : ""} key={option} onClick={() => saveReflection(option)}>{option}</button>)}
            </div>
            <p className="ai-message">{reflectionTip((data.reflectionByDate ?? {})[todayKey()])}</p>
          </Panel>

          <Panel title="Grandes marcos">
            <div className="milestone-card">
              <strong>{milestone.title}</strong>
              <p>{milestone.message}</p>
              <span>{milestone.certificate}</span>
            </div>
          </Panel>

          <Panel title="Certificados">
            <div className="badge-grid">
              {[5, 10, 15, 20, 25, 50].map((kg) => <span className={weightLost >= kg ? "earned" : ""} key={kg}>Certificado: perdeu {kg} kg</span>)}
              <span className={legacy.unlocked ? "earned" : ""}>Certificado: concluiu a missao</span>
            </div>
          </Panel>

          <Panel title="Sistema de marcos">
            <div className="badge-grid">
              {milestoneSystem.map((item) => <span className={item.done ? "earned" : ""} key={item.kg}>{item.kg} kg | Medalha + Certificado + XP</span>)}
            </div>
          </Panel>

          <Panel title="Caixa de recompensas">
            <button className={rewardBoxOpen ? "reward-box open" : "reward-box"} onClick={openRewardBox}>
              {rewardBoxOpen ? "XP +50 | Medalha | Insignia | Recompensa" : "Abrir caixa"}
            </button>
          </Panel>

          <Panel title="Minigame de evolucao">
            <Metric label="Moedas" value={`${data.coins ?? 0}`} note="ganhas com registros" />
            <Metric label="Cosmeticos" value={`${data.achievements.filter((item) => item.includes("cosmetico")).length}`} note="itens liberados" />
            <button className="claim-button" onClick={claimMiniGame}>Resgatar treino do dia</button>
          </Panel>

          <Panel title="Compartilhamento">
            <div className="share-card">
              <strong>Meta Prato</strong>
              <span>Peso inicial: {data.initialWeight} kg</span>
              <span>Peso atual: {data.currentWeight} kg</span>
              <span>Perdidos: {weightLost.toFixed(1)} kg</span>
              <span>Sequencia: {data.streak} dias</span>
              <span>Patente: {rank.name}</span>
              <span>Proxima meta: {nextCampaignTarget(data)} kg</span>
            </div>
            <button className="claim-button" onClick={shareProgress}>Salvar ou compartilhar</button>
          </Panel>

          <Panel title="Exportacao">
            <div className="profile-actions">
              <button onClick={generatePdfReport}>PDF</button>
              <button onClick={() => exportDataFile("csv")}>CSV</button>
              <button onClick={() => exportDataFile("xls")}>Excel</button>
            </div>
            <p className="panel-copy">Exporta peso, agua, refeicoes, sintomas e estatisticas.</p>
          </Panel>

          <Panel title="Backup">
            <div className="profile-actions">
              <button onClick={exportJsonBackup}>Exportar JSON</button>
              <button onClick={generatePdfReport}>Exportar PDF</button>
              <button onClick={() => exportDataFile("xls")}>Exportar Excel</button>
            </div>
            <label className="file-action">Restaurar backup<input type="file" accept="application/json" onChange={restoreJsonBackup} /></label>
          </Panel>

          <Panel title="Registro por voz">
            <form className="routine-form" onSubmit={registerVoiceMeal}>
              <label>Fale ou digite sua refeicao<input value={voiceText} placeholder="Comi um hamburguer e tomei um copo de suco" onChange={(event) => setVoiceText(event.target.value)} /></label>
              <ActionButton type="submit">Criar refeicao</ActionButton>
            </form>
            <p className="panel-copy">A IA local estima os itens e pede foto se desejar no fluxo do prato.</p>
          </Panel>

          <Panel title="Comunidade opcional">
            <div className="community-feed">
              <span>500 pessoas completaram a missao de agua hoje.</span>
              <span>124 medalhas de sequencia liberadas.</span>
              <span>Sem ranking de peso. Apenas conquistas e constancia.</span>
            </div>
          </Panel>

          <Panel title="Centro medico informativo">
            <Metric label="Peso" value={`${data.currentWeight.toFixed(1)} kg`} note="atual" />
            <Metric label="IMC" value={bmi.toFixed(1)} note={bmiLabel(bmi)} />
            <Metric label="Sintomas" value={`${(data.symptoms ?? []).length}`} note="registrados" />
            <Metric label="Historico" value={`${data.meals.length}`} note="refeicoes" />
            <p className="urgent-alert">Informacoes educativas. Nao substituem avaliacao profissional.</p>
          </Panel>

          <Panel title="Cofre de conquistas">
            <div className="vault-grid">
              <span>Medalhas: {achievements.filter((item) => item.done).length}</span>
              <span>Certificados: {milestone.title}</span>
              <span>Recordes: {data.streak} dias</span>
              <span>Fotos antes/depois: {(data.bodyPhotos ?? []).length}</span>
              <span>Relatorios: PDF, CSV e Excel</span>
            </div>
          </Panel>

          <Panel title="Museu da jornada">
            <div className="vault-grid">
              <span>Medalhas: {achievements.filter((item) => item.done).length}</span>
              <span>Fotos antigas: {(data.bodyPhotos ?? []).length}</span>
              <span>Pesos antigos: {data.weights.length}</span>
              <span>Patentes antigas: {rankTable.filter(([, xp]) => data.xp >= xp).length}</span>
              <span>Graficos historicos: peso, agua, medidas</span>
            </div>
          </Panel>

          <Panel title="Modo seguranca">
            <div className="safety-alerts">
              {safetyWarnings.length ? safetyWarnings.map((warning) => <p key={warning}>{warning}</p>) : <p>Sem padroes preocupantes detectados hoje.</p>}
            </div>
          </Panel>

          <Panel title="Modo Jarvis">
            <div className="coach-list jarvis-list">
              {jarvisMessages.map((message) => <p key={message}>{message}</p>)}
            </div>
          </Panel>

          <Panel title="Modo legado">
            <div className={legacy.unlocked ? "legacy-card unlocked" : "legacy-card"}>
              <strong>{legacy.title}</strong>
              <p>{legacy.message}</p>
              <span>Certificado | Patente maxima | Relatorio completo | Linha do tempo | Medalha permanente</span>
            </div>
          </Panel>

          <Panel title="Final da missao">
            <div className={finalMission.unlocked ? "legacy-card unlocked" : "legacy-card"}>
              <strong>{finalMission.title}</strong>
              <p>{finalMission.items.join(" | ")}</p>
            </div>
          </Panel>

          <Panel title="Hall da fama">
            <div className="hall-card">
              <span>INICIO: {data.initialWeight} kg</span>
              <span>ATUAL: {data.currentWeight} kg</span>
              <span>PERDIDOS: {weightLost.toFixed(1)} kg</span>
              <span>SEQUENCIA: {data.streak} dias</span>
              <span>PATENTE: {rank.name}</span>
              <span>CONQUISTAS: {hall.achievements}</span>
              <span>RECOMPENSAS: {hall.rewards}</span>
              <span>MISSÕES COMPLETAS: {hall.missions}</span>
            </div>
          </Panel>

          <Panel title="Pesquisa global">
            <form className="routine-form" onSubmit={(event) => event.preventDefault()}>
              <label>Buscar no historico<input value={searchQuery} placeholder="agua, arroz, sintoma, peso..." onChange={(event) => setSearchQuery(event.target.value)} /></label>
            </form>
            <div className="history-list">
              {searchResults.slice(0, 5).map((result) => <div className="history-row" key={result}><span className="meal-thumb">SR</span><div><strong>{result}</strong></div></div>)}
            </div>
          </Panel>

          <Panel title="Feedback do dia">
            <form className="routine-form" onSubmit={saveDailyFeedback}>
              <label>Como foi seu dia?<textarea value={dayFeedback} onChange={(event) => setDayFeedback(event.target.value)} /></label>
              <ActionButton type="submit">Salvar feedback</ActionButton>
            </form>
          </Panel>

          <Panel title="Configuracoes avancadas">
            <div className="settings-grid">
              {(["haptics", "smartNotifications", "cloudBackup", "appleHealth", "googleFit", "seasonalEvents"] as const).map((key) => <button className={data.settings?.[key] ? "selected" : ""} key={key} onClick={() => toggleSetting(key)}>{key}</button>)}
            </div>
          </Panel>

          <Panel title="Missao do dia">
            <div className="special-missions">
              {dailyMission.items.map((item) => <div key={item.text}><strong>{item.done ? "Concluido" : "Em andamento"}</strong><ProgressBar value={item.done ? 100 : item.progress} /><small>{item.text}</small></div>)}
            </div>
            <div className={dailyMission.completed ? "legacy-card unlocked" : "legacy-card"}>
              <strong>{dailyMission.completed ? "MISSAO CONCLUIDA" : "Missao principal"}</strong>
              <p>{dailyMission.completed ? "XP + medalha + som de conquista liberados." : "Complete agua, refeicoes, fotos e meta diaria."}</p>
            </div>
          </Panel>

          <Panel title="Central de missoes">
            <div className="vault-grid">
              <span><b>Principal</b>{dailyMission.completed ? "Concluida" : `${daily}% hoje`}</span>
              <span><b>Secundarias</b>{challengeList.filter((item) => item.progress >= 100).length}/{challengeList.length}</span>
              <span><b>Secretas</b>{secretMissionsFor(data).filter((item) => item.done).length}/{secretMissionsFor(data).length}</span>
              <span><b>Eventos</b>{seasonalEvents.length} ativos</span>
            </div>
          </Panel>

          <Panel title="Missao do mes">
            <div className="special-missions">
              {monthlyMission.map((mission) => <div key={mission.text}><strong>{mission.text}</strong><ProgressBar value={mission.progress} /><small>{mission.reward}</small></div>)}
            </div>
          </Panel>

          <Panel title="Cartao de operador">
            <div className="operator-card">
              <span>OPERADOR: {currentPatient.nickname || currentPatient.name}</span>
              <span>INICIO DA MISSAO: {data.startedAt.slice(0, 10)}</span>
              <span>PESO INICIAL: {data.initialWeight} kg</span>
              <span>PESO ATUAL: {data.currentWeight} kg</span>
              <span>PESO PERDIDO: {weightLost.toFixed(1)} kg</span>
              <span>DIAS ATIVOS: {appStats.daysUsing}</span>
              <span>PATENTE: {rank.name}</span>
            </div>
          </Panel>

          <Panel title="Museu de conquistas">
            <div className="vault-grid">
              {inventory.map((item) => <span className={item.unlocked ? "earned" : ""} key={item.name}><b>{item.type}</b>{item.name}</span>)}
            </div>
          </Panel>

          <Panel title="Editor de perfil">
            <div className="theme-grid">
              {(["military", "future", "corporate", "minimal", "blackout"] as const).map((theme) => <button className={(data.settings?.theme ?? "military") === theme ? "selected" : ""} key={`profile-${theme}`} onClick={() => updateTheme(theme)}>{theme}</button>)}
            </div>
            <div className="profile-actions">
              <button>Avatar {avatar.uniform}</button>
              <button>Moldura {rank.name}</button>
              <button>Insignia favorita</button>
            </div>
          </Panel>

          <Panel title="Sala de guerra">
            <Metric label="Proxima meta" value={`${nextCampaignTarget(data)} kg`} note={`${daysRemainingToGoal(data)} dias estimados`} />
            <Metric label="Proxima recompensa" value={(data.shopRewards ?? []).find((reward) => !reward.claimed)?.name ?? data.rewards.weekly} note="loja pessoal" />
            <Metric label="Proxima patente" value={rank.nextName} note={`${Math.max(0, rank.nextXp - data.xp)} XP faltando`} />
            <Metric label="Semana / Mes" value={`${weekly}% / ${monthly}%`} note="estatisticas" />
          </Panel>

          <Panel title="Radar de risco">
            <div className="safety-alerts">
              {riskRadar.map((item) => <p key={item}>{item}</p>)}
            </div>
          </Panel>

          <Panel title="Centro de insights">
            <div className="coach-list">
              {advancedInsights.map((item) => <p key={item}>{item}</p>)}
            </div>
          </Panel>

          <Panel title="Memoria inteligente">
            <div className="vault-grid">
              <span><b>Horario comum</b>{analytics.commonHour}h</span>
              <span><b>Alimentos frequentes</b>{favoriteFoods(data).join(", ") || "Sem historico"}</span>
              <span><b>Agua media</b>{analytics.avgWater.toFixed(0)} ml</span>
              <span><b>Perfil</b>{personalityProfile(data)}</span>
            </div>
          </Panel>

          <Panel title="Gêmeo digital">
            <div className="digital-twin">
              <div className="avatar-body stage-1"><span>Hoje</span></div>
              <div className="avatar-body stage-2"><span>30d</span></div>
              <div className="avatar-body stage-3"><span>90d</span></div>
              <div className="avatar-body stage-4"><span>Meta</span></div>
            </div>
            <div className="vault-grid">
              {futureSelf.map((item) => <span key={item.label}><b>{item.label}</b>{item.value}</span>)}
            </div>
          </Panel>

          <Panel title="Modo consulta">
            <div className="profile-actions">
              <button onClick={generatePdfReport}>Gerar pagina medica</button>
              <button onClick={() => exportDataFile("xls")}>Exportar exames e historico</button>
            </div>
            <p className="panel-copy">Inclui peso, agua, refeicoes, sintomas, sono, check-up, medidas e fotos corporais.</p>
          </Panel>

          <Panel title="Laboratorio de IA">
            <div className="coach-list">
              <p>Qual horario sou mais consistente? {analytics.commonHour}h.</p>
              <p>Qual mes foi melhor? {dataCenter.bestMonthLabel}.</p>
              <p>Quanto tempo ate a meta? {predictedGoalDate}.</p>
            </div>
          </Panel>

          <Panel title="IA multimodal">
            <div className="cloud-grid">
              <span>Fotos de pratos</span>
              <span>Texto e voz</span>
              <span>Estatisticas</span>
              <span>Historico</span>
              <span>Perguntas sobre progresso</span>
            </div>
            <p className="ai-message">Exemplo: sua semana mais disciplinada esta ligada aos dias com mais agua e registros completos.</p>
          </Panel>

          <Panel title="Busca universal">
            <form className="routine-form" onSubmit={(event) => event.preventDefault()}>
              <label>Pesquisar qualquer coisa<input value={searchQuery} placeholder="Pizza, agua, julho, quando perdi 10 kg..." onChange={(event) => setSearchQuery(event.target.value)} /></label>
            </form>
            <div className="history-list">
              {searchResults.slice(0, 6).map((result) => <div className="history-row" key={`universal-${result}`}><span className="meal-thumb">AI</span><div><strong>{result}</strong></div></div>)}
            </div>
          </Panel>

          <Panel title="Planejador semanal">
            <div className="vault-grid">
              <span><b>Objetivo</b>Cumprir 80% da semana</span>
              <span><b>Agua</b>{data.waterGoalMl} ml por dia</span>
              <span><b>Peso</b>{smartGoals.weekly.toFixed(1)} kg alvo</span>
              <span><b>Recompensa</b>{data.rewards.weekly}</span>
              <span><b>Desafios</b>{challengeList.length} ativos</span>
            </div>
          </Panel>

          <Panel title="Dashboard modular">
            <div className="settings-grid">
              {["Peso", "Agua", "Proxima refeicao", "Calendario", "Missoes", "Graficos", "Recompensas", "Sequencia"].map((widget) => <button className="selected" key={widget}>{widget}</button>)}
            </div>
            <p className="panel-copy">Widgets prontos para organizar a tela inicial.</p>
          </Panel>

          <Panel title="Modo restaurante">
            <div className="profile-actions">
              <button onClick={() => setTodayPlan("Comer fora")}>Vou comer fora hoje</button>
              <label className="file-action">Foto no restaurante<input type="file" accept="image/*" capture="environment" onChange={handlePhoto} /></label>
            </div>
            <p className="ai-message">{planningAdvice("Comer fora")}</p>
          </Panel>

          <Panel title="Maquina do tempo">
            <div className="timeline-list">
              {timeline.concat(data.weights.slice(-4).map((entry) => ({ date: entry.date, label: `${entry.weight} kg registrados`, done: true }))).slice(-8).map((item) => <span className={item.done ? "done" : ""} key={`${item.date}-${item.label}`}><b>{item.date}</b>{item.label}</span>)}
            </div>
          </Panel>

          <Panel title="Mapa de progresso mundial">
            <Metric label="Peso perdido" value={`${weightLost.toFixed(1)} kg`} note={`${worldMap.km} km percorridos`} />
            <Metric label="Destino atual" value={worldMap.city} note="jornada visual" />
            <ProgressBar value={worldMap.progress} />
          </Panel>

          <Panel title="Ilha da evolucao">
            <div className="legacy-card unlocked">
              <strong>{island.name}</strong>
              <p>{island.description}</p>
              <span>{island.next}</span>
            </div>
          </Panel>

          <Panel title="Mascote virtual">
            <div className="avatar-card">
              <div className="avatar-body stage-2"><span>{pet.stage}</span></div>
              <div><strong>{pet.name}</strong><p>{pet.message}</p><small>{pet.bonus}</small></div>
            </div>
          </Panel>

          <Panel title="Arvore de habilidades">
            <div className="badge-grid">
              {skillTree.map((skill) => <span className={skill.level > 0 ? "earned" : ""} key={skill.name}>{skill.name} nivel {skill.level}</span>)}
            </div>
          </Panel>

          <Panel title="Passe de temporada">
            <div className="season-list">
              {[1, 10, 20, 30, 50].map((tier) => <div key={tier}><strong>Nivel {tier}</strong><ProgressBar value={Math.min(100, (level / tier) * 100)} /><small>{seasonPassReward(tier)}</small></div>)}
            </div>
          </Panel>

          <Panel title="Academia interna">
            <div className="knowledge-list">
              {["Hidratacao", "Leitura de rotulos", "Porcoes", "Habitos", "Sono"].map((course) => <details key={course}><summary>{course}</summary><p>Curso curto com XP, medalha e certificado ao concluir.</p></details>)}
            </div>
          </Panel>

          <Panel title="Sistema de cartas">
            <div className="badge-grid">
              {badgesFor(data).map((badge) => <span className={badge.done ? "earned" : ""} key={`card-${badge.name}`}>Carta: {badge.name}</span>)}
            </div>
          </Panel>

          <Panel title="Laboratorio de habitos">
            <div className="vault-grid">
              <span><b>Semana A</b>Mais agua: {waterPercent}% hoje</span>
              <span><b>Semana B</b>Mais registros: {data.meals.length} refeicoes</span>
              <span><b>Comparacao</b>{waterPercent >= daily ? "Agua esta liderando" : "Registros estao liderando"}</span>
            </div>
          </Panel>

          <Panel title="Liga pessoal">
            <Metric label="Melhor semana" value={`${personalRanking.bestWeek}%`} note="recorde" />
            <Metric label="Melhor mes" value={`${personalRanking.bestMonth}%`} note="recorde" />
            <Metric label="Maior sequencia" value={`${personalRanking.bestStreak} dias`} note="recorde" />
            <Metric label="Maior perda mensal" value={`${personalRanking.healthyLoss.toFixed(1)} kg`} note="controle saudavel" />
          </Panel>

          <Panel title="Modo historia">
            <div className="timeline-list">
              {storyChapters(data).map((chapter) => <span className={chapter.done ? "done" : ""} key={chapter.title}><b>{chapter.title}</b>{chapter.reward}</span>)}
            </div>
          </Panel>

          <Panel title="Replay e trailer da jornada">
            <div className="cinema-frame">
              {biography.map((line) => <p key={line}>{line}</p>)}
            </div>
          </Panel>

          <Panel title="Livro automatico">
            <div className="knowledge-list">
              {["O comeco", "Primeiros 10 kg", "Maiores conquistas", "Meta final", "Estatisticas", "Fotos"].map((chapter) => <details key={`book-${chapter}`}><summary>{chapter}</summary><p>{biography[0] ?? "A jornada comeca no primeiro registro."}</p></details>)}
            </div>
          </Panel>

          <Panel title="Modo familia">
            <div className="cloud-grid">
              <span>Convites familiares</span>
              <span>Compartilhar apenas progresso escolhido</span>
              <span>Mensagens de incentivo</span>
            </div>
          </Panel>

          <Panel title="Compartilhar com profissional">
            <div className="profile-actions">
              <button onClick={generatePdfReport}>Gerar PDF profissional</button>
              <button onClick={shareProgress}>Gerar resumo compartilhavel</button>
            </div>
          </Panel>

          <Panel title="Modo empresa">
            <div className="cloud-grid">
              <span>Perfis familiares</span>
              <span>Perfis para profissionais</span>
              <span>Dashboard administrativo</span>
              <span>Relatorios agregados</span>
            </div>
          </Panel>

          <Panel title="API publica futura">
            <div className="cloud-grid">
              <span>Apple Health</span>
              <span>Google Fit</span>
              <span>Smartwatches</span>
              <span>Balancas inteligentes</span>
              <span>Outros apps</span>
            </div>
          </Panel>

          <Panel title="Universo expandido">
            <div className="vault-grid">
              {lifeOs.map((module) => <span className={module.active ? "earned" : ""} key={module.name}><b>{module.name}</b>{module.status}</span>)}
            </div>
          </Panel>

          <Panel title="Modo lenda">
            <div className={legacy.unlocked ? "legend-card unlocked" : "legend-card"}>
              <strong>{legacy.unlocked ? "GENERAL LENDARIO" : "Modo Lenda bloqueado"}</strong>
              <span>Operador: {currentPatient.nickname || currentPatient.name}</span>
              <span>Peso inicial: {data.initialWeight} kg</span>
              <span>Peso final: {data.targetWeight} kg</span>
              <span>Total perdido: {weightLost.toFixed(1)} kg</span>
              <span>Agua registrada: {appStats.waterLiters.toFixed(1)} L</span>
              <span>Refeicoes: {data.meals.length}</span>
              <span>Fotos: {data.meals.filter((meal) => meal.photo).length + (data.bodyPhotos ?? []).length}</span>
            </div>
          </Panel>

          <Panel title="Tutorial e eventos">
            <div className="community-feed">
              <span>1. Cadastre peso, agua e primeira refeicao.</span>
              <span>2. Tire foto do prato para liberar XP extra.</span>
              <span>3. Evento sazonal: Operacao Constancia de Junho.</span>
              {seasonalEvents.map((event) => <span key={event}>{event}</span>)}
            </div>
          </Panel>
        </section>

        <section className="reward-grid" id="recompensas">
          <SectionTitle title="Recompensas" />
          <RewardPanel
            unlocked={weeklyUnlocked(data)}
            title="Meta semanal concluida"
            value={data.rewards.weekly}
            examples={rewardExamples}
            warning="Recompensa e comemoracao controlada. Nao e dia de exagerar."
            onChange={(value) => commitData({ ...data, rewards: { ...data.rewards, weekly: value } })}
          />
          <RewardPanel
            unlocked={monthlyUnlocked(data)}
            title="Super missao mensal concluida"
            value={data.rewards.monthly}
            examples={superRewardExamples}
            warning="Aproveite a recompensa e volte para a rotina na proxima refeicao."
            onChange={(value) => commitData({ ...data, rewards: { ...data.rewards, monthly: value } })}
          />
        </section>
        </> : null}

        <footer className="safety-note">Este app e auxiliar. Nao substitui medico ou nutricionista.</footer>
      </div>

      <nav className="bottom-nav">
        {["Inicio", "Historico", "Missoes", "Perfil"].map((item, index) => (
          <a href={index === 0 ? "#painel" : `#${item.toLowerCase()}`} key={item}>{item}</a>
        ))}
      </nav>
    </main>
  );
}

function OnboardingWizard({
  step,
  data,
  onStepChange,
  onChange,
  onFinish
}: {
  step: number;
  data: {
    currentWeight: number;
    targetWeight: number;
    objective: Patient["objective"];
    monthlyWeightGoal: number;
    weeklyReward: string;
    monthlyReward: string;
  };
  onStepChange: (step: number) => void;
  onChange: (data: Partial<{
    currentWeight: number;
    targetWeight: number;
    objective: Patient["objective"];
    monthlyWeightGoal: number;
    weeklyReward: string;
    monthlyReward: string;
  }>) => void;
  onFinish: () => void;
}) {
  const next = () => onStepChange(Math.min(6, step + 1));
  const back = () => onStepChange(Math.max(1, step - 1));

  return (
    <div className="onboarding-backdrop">
      <section className="onboarding-card">
        <Brand />
        <p className="mission-badge">MISSÃO INICIADA</p>
        <h2>Bem-vindo ao Meta Prato. Sua jornada começa agora.</h2>
        <ProgressBar value={(step / 6) * 100} />

        {step === 1 ? <label>Peso atual<input type="number" value={data.currentWeight} onChange={(event) => onChange({ currentWeight: Number(event.target.value) })} /></label> : null}
        {step === 2 ? <label>Peso desejado<input type="number" value={data.targetWeight} onChange={(event) => onChange({ targetWeight: Number(event.target.value) })} /></label> : null}
        {step === 3 ? <div className="radio-grid">
          {[
            ["lose", "Emagrecer"],
            ["maintain", "Manter peso"],
            ["gain", "Ganhar peso"]
          ].map(([value, label]) => (
            <button key={value} className={data.objective === value ? "selected" : ""} onClick={() => onChange({ objective: value as Patient["objective"] })}>{label}</button>
          ))}
        </div> : null}
        {step === 4 ? <label>Meta mensal de perda de peso<input type="number" step="0.1" value={data.monthlyWeightGoal} onChange={(event) => onChange({ monthlyWeightGoal: Number(event.target.value) })} /></label> : null}
        {step === 5 ? <label>Recompensa semanal favorita<input value={data.weeklyReward} onChange={(event) => onChange({ weeklyReward: event.target.value })} /></label> : null}
        {step === 6 ? <label>Super recompensa mensal favorita<input value={data.monthlyReward} onChange={(event) => onChange({ monthlyReward: event.target.value })} /></label> : null}

        <div className="wizard-actions">
          <button disabled={step === 1} onClick={back}>Voltar</button>
          {step < 6 ? <button onClick={next}>Avancar</button> : <button onClick={onFinish}>INICIAR MISSAO</button>}
        </div>
      </section>
    </div>
  );
}

function LoginPage({
  email,
  password,
  patients,
  registerForm,
  mode,
  createStep,
  error,
  rememberMe,
  recoveryEmail,
  recoverySent,
  onModeChange,
  onCreateStepChange,
  onEmailChange,
  onPasswordChange,
  onRememberChange,
  onRecoveryEmailChange,
  onSubmit,
  onRegister,
  onRecover,
  onRegisterChange,
  onEnterCreated
}: {
  email: string;
  password: string;
  patients: Patient[];
  registerForm: PatientForm;
  mode: AuthMode;
  createStep: number;
  error: string;
  rememberMe: boolean;
  recoveryEmail: string;
  recoverySent: boolean;
  onModeChange: (mode: AuthMode) => void;
  onCreateStepChange: (step: number) => void;
  onEmailChange: (value: string) => void;
  onPasswordChange: (value: string) => void;
  onRememberChange: (value: boolean) => void;
  onRecoveryEmailChange: (value: string) => void;
  onSubmit: (event: FormEvent) => void;
  onRegister: (event: FormEvent) => void;
  onRecover: (event: FormEvent) => void;
  onRegisterChange: <K extends keyof PatientForm>(key: K, value: PatientForm[K]) => void;
  onEnterCreated: () => void;
}) {
  const rules = passwordRules(registerForm.password);
  const personalReady = Boolean(registerForm.name.trim() && registerForm.birthDate && registerForm.sex);
  const accessReady = Boolean(
    registerForm.email &&
    registerForm.confirmEmail &&
    registerForm.email === registerForm.confirmEmail &&
    registerForm.password === registerForm.confirmPassword &&
    Object.values(rules).every(Boolean)
  );

  const startCreate = () => {
    onModeChange("create");
    onCreateStepChange(1);
  };

  return (
    <main className="login-canvas">
      <section className="auth-stage">
        <header className="auth-title">
          <p>Antes de usar o app</p>
          <h1>Faca seu cadastro</h1>
          <span>Preencha seus dados para criar sua conta e comecar sua jornada.</span>
        </header>

        <div className="auth-phone-grid">
          {mode === "welcome" ? (
            <article className="auth-phone welcome-phone">
              <div className="phone-top" />
              <div className="phone-brand-mark">MP</div>
              <h2>Meta <span>Prato</span></h2>
              <p className="phone-motto">Disciplina diaria. Resultados permanentes.</p>
              <h3>Crie sua conta</h3>
              <p>Preencha seus dados para comecar sua jornada.</p>
              <button className="phone-primary" type="button" onClick={startCreate}>Vamos comecar</button>
              <button className="phone-link" type="button" onClick={() => onModeChange("login")}>Ja tem uma conta? Entrar</button>
              <div className="phone-benefits">
                <span>Seu corpo</span>
                <span>Sua missao</span>
                <span>Seu resultado</span>
              </div>
              <div className="phone-dots"><span className="on" /><span /><span /></div>
            </article>
          ) : null}

          {mode === "create" ? (
            <form className="auth-phone form-phone" onSubmit={onRegister}>
              <div className="phone-nav">
                <button type="button" onClick={() => (createStep === 1 ? onModeChange("welcome") : onCreateStepChange(createStep - 1))}>Voltar</button>
                <strong>Criar conta</strong>
              </div>
              <StepBars step={createStep} total={3} />

              {createStep === 1 ? (
                <div className="phone-step">
                  <h3>Dados pessoais</h3>
                  <p>Informe seus dados para continuar.</p>
                  <label>Nome completo<input value={registerForm.name} placeholder="Digite seu nome completo" onChange={(event) => onRegisterChange("name", event.target.value)} /></label>
                  <label>Apelido opcional<input value={registerForm.nickname} placeholder="Como quer ser chamado" onChange={(event) => onRegisterChange("nickname", event.target.value)} /></label>
                  <label>Data de nascimento<input type="date" value={registerForm.birthDate} onChange={(event) => onRegisterChange("birthDate", event.target.value)} /></label>
                  <label>Sexo<select value={registerForm.sex} onChange={(event) => onRegisterChange("sex", event.target.value)}>
                    <option value="">Selecione seu sexo</option>
                    <option>Feminino</option>
                    <option>Masculino</option>
                    <option>Outro</option>
                    <option>Prefiro nao informar</option>
                  </select></label>
                  <button className="phone-primary" type="button" disabled={!personalReady} onClick={() => onCreateStepChange(2)}>Continuar</button>
                </div>
              ) : null}

              {createStep === 2 ? (
                <div className="phone-step">
                  <h3>Dados da conta</h3>
                  <p>Informe seus dados de acesso.</p>
                  <label>E-mail<input type="email" value={registerForm.email} placeholder="seuemail@exemplo.com" onChange={(event) => onRegisterChange("email", event.target.value)} /></label>
                  <label>Confirmar e-mail<input type="email" value={registerForm.confirmEmail} placeholder="confirme seu e-mail" onChange={(event) => onRegisterChange("confirmEmail", event.target.value)} /></label>
                  <label>Senha<input type="password" value={registerForm.password} placeholder="Crie uma senha segura" onChange={(event) => onRegisterChange("password", event.target.value)} /></label>
                  <label>Confirmar senha<input type="password" value={registerForm.confirmPassword} placeholder="Confirme sua senha" onChange={(event) => onRegisterChange("confirmPassword", event.target.value)} /></label>
                  <div className="password-rules">
                    <span className={rules.length ? "ok" : ""}>Minimo 8 caracteres</span>
                    <span className={rules.uppercase ? "ok" : ""}>Pelo menos 1 letra maiuscula</span>
                    <span className={rules.number ? "ok" : ""}>Letras e numeros</span>
                    <span className={rules.special ? "ok" : ""}>Pelo menos 1 caractere especial</span>
                  </div>
                  <button className="phone-primary" type="button" disabled={!accessReady} onClick={() => onCreateStepChange(3)}>Continuar</button>
                </div>
              ) : null}

              {createStep === 3 ? (
                <div className="phone-step">
                  <h3>Informacoes iniciais</h3>
                  <p>Conte-nos mais sobre voce.</p>
                  <label>Peso atual (kg)<input type="number" min="1" step="0.1" value={registerForm.initialWeight} onChange={(event) => onRegisterChange("initialWeight", Number(event.target.value))} /></label>
                  <label>Altura (cm)<input type="number" min="1" value={registerForm.heightCm} onChange={(event) => onRegisterChange("heightCm", Number(event.target.value))} /></label>
                  <label>Objetivo de peso (kg)<input type="number" min="1" step="0.1" value={registerForm.targetWeight} onChange={(event) => onRegisterChange("targetWeight", Number(event.target.value))} /></label>
                  <label>Nivel de atividade fisica<select value={registerForm.plan} onChange={(event) => onRegisterChange("plan", event.target.value)}>
                    <option value="">Selecione seu nivel</option>
                    <option>Baixo</option>
                    <option>Moderado</option>
                    <option>Alto</option>
                  </select></label>
                  <label className="switch-line"><span>Aceito os termos de uso e politica de privacidade</span><input type="checkbox" checked={registerForm.acceptedTerms && registerForm.acceptedPrivacy} onChange={(event) => {
                    onRegisterChange("acceptedTerms", event.target.checked);
                    onRegisterChange("acceptedPrivacy", event.target.checked);
                  }} /></label>
                  {error ? <p className="login-error">{error}</p> : null}
                  <button className="phone-primary">Criar conta</button>
                </div>
              ) : null}

              <button className="phone-link" type="button" onClick={() => onModeChange("login")}>Ja tem uma conta? Entrar</button>
            </form>
          ) : null}

          {mode === "created" ? (
            <article className="auth-phone success-phone">
              <div className="success-shield">MP</div>
              <h3>Conta criada com sucesso!</h3>
              <p>Bem-vindo a sua missao. Agora e hora de disciplina e foco para alcancar seus objetivos.</p>
              <button className="phone-primary" type="button" onClick={onEnterCreated}>Entrar no app</button>
            </article>
          ) : null}

          {mode === "login" ? (
            <form className="auth-phone form-phone login-phone" onSubmit={onSubmit}>
              <div className="phone-top" />
              <h3>Entrar na sua conta</h3>
              <p>Bem-vindo de volta!</p>
              <label>E-mail<input value={email} type="email" placeholder="seuemail@exemplo.com" onChange={(event) => onEmailChange(event.target.value)} /></label>
              <label>Senha<input value={password} type="password" placeholder="Digite sua senha" onChange={(event) => onPasswordChange(event.target.value)} /></label>
              <div className="login-options">
                <label className="check-line"><input type="checkbox" checked={rememberMe} onChange={(event) => onRememberChange(event.target.checked)} /> Lembrar-me</label>
                <button type="button" onClick={() => onModeChange("recover")}>Esqueceu sua senha?</button>
              </div>
              {error ? <p className="login-error">{error}</p> : null}
              <button className="phone-primary">Entrar</button>
              <div className="auth-divider"><span>ou</span></div>
              <button className="google-button" type="button">Entrar com Google</button>
              <button className="google-button" type="button">Entrar com Apple</button>
              <button className="phone-link" type="button" onClick={startCreate}>Nao tem uma conta? Criar conta</button>
            </form>
          ) : null}

          {mode === "recover" ? (
            <form className="auth-phone form-phone login-phone" onSubmit={onRecover}>
              <div className="phone-nav">
                <button type="button" onClick={() => onModeChange("login")}>Voltar</button>
                <strong>Recuperar senha</strong>
              </div>
              <h3>Redefinir acesso</h3>
              <p>Informe seu e-mail para receber o link de recuperacao.</p>
              <label>E-mail<input value={recoveryEmail} type="email" placeholder="seuemail@exemplo.com" onChange={(event) => onRecoveryEmailChange(event.target.value)} /></label>
              <button className="phone-primary">Enviar link de recuperacao</button>
              {recoverySent ? <p className="login-success">Se este email estiver cadastrado, enviaremos um link para redefinir sua senha.</p> : null}
            </form>
          ) : null}
        </div>

        {mode !== "create" && mode !== "created" ? (
          <div className="patient-roster compact-roster">
            {patients.map((patient) => (
              <button
                key={patient.id}
                onClick={() => {
                  onEmailChange(patient.email);
                  onPasswordChange("Senha@123");
                  onModeChange("login");
                }}
              >
                <strong>{patient.name}</strong>
                <span>{patient.email}</span>
              </button>
            ))}
          </div>
        ) : null}

        <footer className="auth-warning">
          <Brand compact />
          <div>
            <strong>Importante</strong>
            <p>Este aplicativo e um auxiliar de organizacao alimentar e nao substitui orientacao medica ou nutricional.</p>
          </div>
          <span>Foco</span>
          <span>Disciplina</span>
          <span>Constancia</span>
          <span>Resultados</span>
        </footer>
      </section>
    </main>
  );

  return (
    <main className="login-canvas">
      <section className="login-shell">
        <div className="login-hero">
          <Brand />
          <p className="login-motto">Disciplina diaria. Resultados permanentes.</p>
          <h1>{mode === "welcome" ? "Bem-vindo ao Meta Prato" : "Central do paciente"}</h1>
          <p>Controle suas refeicoes, acompanhe metas e evolua todos os dias.</p>
          <div className="login-stats">
            <span><b>{patients.length}</b> pacientes</span>
            <span><b>2.300 ml</b> agua padrao</span>
            <span><b>Email</b> + senha</span>
          </div>
          {mode === "welcome" ? (
            <div className="welcome-actions">
              <button onClick={() => onModeChange("create")}>Criar Conta</button>
              <button className="dark" onClick={() => onModeChange("login")}>Entrar</button>
            </div>
          ) : null}
        </div>

        {mode === "login" ? <form className="login-card" onSubmit={onSubmit}>
          <h2>Login</h2>
          <label>
            Email
            <input value={email} type="email" onChange={(event) => onEmailChange(event.target.value)} />
          </label>
          <label>
            Senha
            <input value={password} type="password" onChange={(event) => onPasswordChange(event.target.value)} />
          </label>
          <div className="login-options">
            <label className="check-line"><input type="checkbox" checked={rememberMe} onChange={(event) => onRememberChange(event.target.checked)} /> Lembrar-me</label>
            <button type="button" onClick={() => onModeChange("recover")}>Esqueci minha senha</button>
          </div>
          {error ? <p className="login-error">{error}</p> : null}
          <button>ENTRAR</button>
          <small>Pacientes de teste usam senha Senha@123.</small>
        </form> : null}

        {mode === "recover" ? <form className="login-card" onSubmit={onRecover}>
          <h2>Recuperar senha</h2>
          <label>
            Email
            <input value={recoveryEmail} type="email" onChange={(event) => onRecoveryEmailChange(event.target.value)} />
          </label>
          <button>ENVIAR LINK DE RECUPERACAO</button>
          {recoverySent ? (
            <p className="login-success">Se este email estiver cadastrado, enviaremos um link para redefinir sua senha.</p>
          ) : null}
          <button className="text-button" type="button" onClick={() => onModeChange("login")}>Voltar ao login</button>
        </form> : null}

        {mode === "created" ? <div className="login-card mission-started">
          <h2>MISSÃO INICIADA</h2>
          <p>Bem-vindo ao Meta Prato. Sua jornada começa agora.</p>
          <button onClick={() => onModeChange("login")}>Continuar</button>
        </div> : null}

        {mode === "create" ? <form className="register-card" onSubmit={onRegister}>
          <h2>Cadastrar paciente</h2>
          <div className="register-grid">
            <label>Nome completo<input value={registerForm.name} onChange={(event) => onRegisterChange("name", event.target.value)} /></label>
            <label>Apelido opcional<input value={registerForm.nickname} onChange={(event) => onRegisterChange("nickname", event.target.value)} /></label>
            <label>Data de nascimento<input type="date" value={registerForm.birthDate} onChange={(event) => onRegisterChange("birthDate", event.target.value)} /></label>
            <label>Sexo<select value={registerForm.sex} onChange={(event) => onRegisterChange("sex", event.target.value)}>
              <option value="">Selecionar</option>
              <option>Feminino</option>
              <option>Masculino</option>
              <option>Outro</option>
              <option>Prefiro nao informar</option>
            </select></label>
            <label>Altura (cm)<input type="number" min="1" value={registerForm.heightCm} onChange={(event) => onRegisterChange("heightCm", Number(event.target.value))} /></label>
            <label>Peso atual (kg)<input type="number" min="1" step="0.1" value={registerForm.initialWeight} onChange={(event) => onRegisterChange("initialWeight", Number(event.target.value))} /></label>
            <label>Peso meta (kg)<input type="number" min="1" step="0.1" value={registerForm.targetWeight} onChange={(event) => onRegisterChange("targetWeight", Number(event.target.value))} /></label>
            <label>Email<input type="email" value={registerForm.email} onChange={(event) => onRegisterChange("email", event.target.value)} /></label>
            <label>Confirmar email<input type="email" value={registerForm.confirmEmail} onChange={(event) => onRegisterChange("confirmEmail", event.target.value)} /></label>
            <label>Senha<input type="password" value={registerForm.password} onChange={(event) => onRegisterChange("password", event.target.value)} /></label>
            <label>Confirmar senha<input type="password" value={registerForm.confirmPassword} onChange={(event) => onRegisterChange("confirmPassword", event.target.value)} /></label>
            <div className="password-rules">
              <span className={rules.length ? "ok" : ""}>Pelo menos 8 caracteres</span>
              <span className={rules.uppercase ? "ok" : ""}>Pelo menos 1 letra maiuscula</span>
              <span className={rules.number ? "ok" : ""}>Pelo menos 1 numero</span>
              <span className={rules.special ? "ok" : ""}>Pelo menos 1 caractere especial</span>
            </div>
            <label className="check-line wide"><input type="checkbox" checked={registerForm.acceptedTerms} onChange={(event) => onRegisterChange("acceptedTerms", event.target.checked)} /> Aceito os Termos de Uso</label>
            <label className="check-line wide"><input type="checkbox" checked={registerForm.acceptedPrivacy} onChange={(event) => onRegisterChange("acceptedPrivacy", event.target.checked)} /> Aceito a Politica de Privacidade</label>
          </div>
          {error ? <p className="login-error">{error}</p> : null}
          <button>CRIAR MINHA CONTA</button>
        </form> : null}

        {mode !== "create" ? <div className="patient-roster">
          {patients.map((patient) => (
            <button
              key={patient.id}
              onClick={() => {
                onEmailChange(patient.email);
                onPasswordChange("Senha@123");
                onModeChange("login");
              }}
            >
              <strong>{patient.name}</strong>
              <span>{patient.email}</span>
              <small>{patient.currentWeight} kg para {patient.targetWeight} kg</small>
            </button>
          ))}
        </div> : null}
      </section>
    </main>
  );
}

function StepBars({ step, total }: { step: number; total: number }) {
  return (
    <div className="step-bars">
      {Array.from({ length: total }).map((_, index) => (
        <span key={index} className={index < step ? "on" : ""} />
      ))}
    </div>
  );
}

function analyzeMeal(grams: number, hint = "") {
  const lower = hint.toLowerCase();
  const matched = foodLibrary.filter((food) => lower.includes(food.name.toLowerCase()));
  const foods = matched.length ? matched : foodLibrary.slice(0, Math.min(3, Math.max(1, Math.round(grams / 180))));
  const share = grams / foods.length;
  const calories = Math.round(foods.reduce((sum, food) => sum + food.calories * share, 0));
  const protein = Math.round(foods.reduce((sum, food) => sum + food.protein * share, 0));
  const carbs = Math.round(foods.reduce((sum, food) => sum + food.carbs * share, 0));
  const fat = Math.round(foods.reduce((sum, food) => sum + food.fat * share, 0));
  const message = grams <= 550
    ? `Prato estimado em ${grams} g. Dentro da meta. Bom trabalho.`
    : `Prato estimado em ${grams} g. Acima da meta. Considere reduzir a porcao.`;
  return { foods: foods.map((food) => food.name), calories, protein, carbs, fat, message };
}

function productFromBarcode(code: string, manualName = "") {
  if (manualName.trim()) {
    const analysis = analyzeMeal(100, manualName);
    return {
      name: manualName.trim(),
      calories: analysis.calories,
      protein: analysis.protein,
      carbs: analysis.carbs,
      fat: analysis.fat
    };
  }
  const last = Number(code.replace(/\D/g, "").slice(-1)) || 0;
  const food = foodLibrary[last % foodLibrary.length];
  return {
    name: `${food.name} escaneado`,
    calories: Math.round(food.calories * 100),
    protein: Math.round(food.protein * 100),
    carbs: Math.round(food.carbs * 100),
    fat: Math.round(food.fat * 100)
  };
}

function rankForXp(xp: number) {
  let index = 0;
  rankTable.forEach(([, required], itemIndex) => {
    if (xp >= required) index = itemIndex;
  });
  const next = rankTable[Math.min(rankTable.length - 1, index + 1)];
  return { name: rankTable[index][0], nextName: next[0], nextXp: next[1] };
}

function bmiFor(weight: number, heightCm: number) {
  const meters = Math.max(1, heightCm) / 100;
  return weight / (meters * meters);
}

function bmiLabel(bmi: number) {
  if (bmi < 18.5) return "baixo peso";
  if (bmi < 25) return "faixa normal";
  if (bmi < 30) return "sobrepeso";
  return "acompanhar rotina";
}

function averageWeightLoss(entries: WeightEntry[], days: number) {
  if (entries.length < 2) return 0;
  const sorted = [...entries].sort((a, b) => a.date.localeCompare(b.date));
  const latest = sorted[sorted.length - 1];
  const latestTime = new Date(`${latest.date}T12:00:00`).getTime();
  const windowStart = latestTime - days * 86400000;
  const first = sorted.find((entry) => new Date(`${entry.date}T12:00:00`).getTime() >= windowStart) ?? sorted[0];
  return Math.max(0, first.weight - latest.weight);
}

function predictGoalDate(currentWeight: number, targetWeight: number, weeklyLoss: number) {
  if (currentWeight <= targetWeight) return "meta atingida";
  if (weeklyLoss <= 0) return "aguardando dados";
  const weeks = Math.ceil((currentWeight - targetWeight) / weeklyLoss);
  const date = new Date();
  date.setDate(date.getDate() + weeks * 7);
  return date.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" });
}

function safetyAlerts(data: AppData) {
  const alerts: string[] = [];
  const todayMeals = data.meals.filter((meal) => meal.date === todayKey());
  const todayGrams = todayMeals.reduce((sum, meal) => sum + meal.grams, 0);
  if (!todayMeals.length) alerts.push("Voce ainda nao registrou refeicoes hoje. Mantenha constancia sem extremos.");
  if (todayMeals.length && todayGrams < 350) alerts.push("Consumo registrado muito baixo. Evite comportamento perigoso e revise sua rotina.");
  if (averageWeightLoss(data.weights, 7) > 2) alerts.push("Seu progresso esta muito acelerado. Considere revisar sua rotina e, se necessario, procurar orientacao profissional.");
  if ((data.symptoms ?? []).some((symptom) => symptom.date === todayKey())) alerts.push("Sintoma forte registrado. Revise sua rotina e procure orientacao medica ou nutricional se necessario.");
  return alerts;
}

function CalendarGrid({ data }: { data: AppData }) {
  const days = Array.from({ length: 14 }).map((_, index) => {
    const date = new Date();
    date.setDate(date.getDate() - (13 - index));
    const key = date.toISOString().slice(0, 10);
    const checklist = data.checklistByDate[key];
    const score = checklist ? Object.values(checklist).filter(Boolean).length / Object.values(checklist).length : 0;
    const status = score >= 0.8 ? "done" : score > 0 ? "partial" : "missed";
    return { key, label: date.getDate(), status };
  });
  return (
    <div className="calendar-grid">
      {days.map((day) => <span className={day.status} key={day.key}>{day.label}</span>)}
    </div>
  );
}

function MeasureBars({ entries }: { entries: AppData["bodyMeasures"] }) {
  const latest = entries[entries.length - 1];
  if (!latest) return <p className="panel-copy">Salve suas medidas para ver a evolucao.</p>;
  const values = [
    ["Cintura", latest.waist],
    ["Peito", latest.chest],
    ["Braco", latest.arm],
    ["Coxa", latest.thigh],
    ["Pescoco", latest.neck]
  ];
  const max = Math.max(...values.map(([, value]) => Number(value)), 1);
  return (
    <div className="measure-bars">
      {values.map(([label, value]) => (
        <span key={label}>
          <b>{label}</b>
          <i style={{ width: `${(Number(value) / max) * 100}%` }} />
          <small>{value} cm</small>
        </span>
      ))}
    </div>
  );
}

function MarketList({ items, onToggle }: { items: AppData["marketItems"]; onToggle: (id: string) => void }) {
  const labels = { shopping: "Compras", favorite: "Favoritos", blocked: "Proibidos por mim" };
  return (
    <div className="market-columns">
      {(["shopping", "favorite", "blocked"] as const).map((type) => (
        <div key={type}>
          <strong>{labels[type]}</strong>
          {items.filter((item) => item.type === type).map((item) => (
            <button className={item.done ? "done" : ""} key={item.id} onClick={() => onToggle(item.id)}>{item.name}</button>
          ))}
        </div>
      ))}
    </div>
  );
}

function HabitList({ habits, onToggle }: { habits: AppData["habits"]; onToggle: (id: string) => void }) {
  return (
    <div className="habit-list">
      {habits.map((habit) => {
        const done = habit.doneDates.includes(todayKey());
        const percent = Math.round((habit.doneDates.length / Math.max(1, daysBetween(new Date(), new Date()) + 7)) * 100);
        return (
          <button className={done ? "done" : ""} key={habit.id} onClick={() => onToggle(habit.id)}>
            <strong>{habit.name}</strong>
            <span>{habit.doneDates.length} dias | {Math.min(100, percent)}%</span>
          </button>
        );
      })}
    </div>
  );
}

function personalRankingStats(data: AppData) {
  const scores = Object.values(data.checklistByDate).map((checklist) => Math.round((Object.values(checklist).filter(Boolean).length / Object.values(checklist).length) * 100));
  const bestWeek = scores.length ? Math.max(...scores.slice(-7)) : 0;
  const bestMonth = scores.length ? Math.round(scores.slice(-30).reduce((sum, value) => sum + value, 0) / Math.max(1, scores.slice(-30).length)) : 0;
  const healthyLoss = Math.min(2, averageWeightLoss(data.weights, 7));
  return { bestWeek, bestMonth, bestStreak: data.streak, healthyLoss };
}

function centralStats(data: AppData) {
  const daysUsing = Math.max(1, daysBetween(new Date(data.startedAt), new Date()) + 1);
  const waterLiters = data.water.reduce((sum, entry) => sum + entry.amount, 0) / 1000;
  const rewards = (data.shopRewards ?? []).filter((reward) => reward.claimed).length;
  return { daysUsing, meals: data.meals.length, waterLiters, bestStreak: data.streak, rewards };
}

function aiCoachMessages(data: AppData, waterToday: number, remainingKg: number, mood?: string) {
  const messages = [
    `Voce esta ha ${data.streak} dias cumprindo metas. Continue construindo consistencia.`,
    waterToday < data.waterGoalMl ? "Sua ingestao de agua esta baixa hoje." : "Agua de hoje em bom ritmo.",
    `Faltam ${remainingKg.toFixed(1)} kg para sua meta final.`
  ];
  if (mood === "Desanimado" || mood === "Muito dificil") messages.unshift("Hoje pode ser mais leve: cumpra o basico e volte na proxima refeicao.");
  if (mood === "Otimo") messages.unshift("Energia alta hoje. Use isso para registrar tudo com calma.");
  return messages;
}

function smartGoalTargets(data: AppData) {
  const weeklyLoss = averageWeightLoss(data.weights, 7);
  const safeWeekly = weeklyLoss > 0 ? Math.min(1.2, weeklyLoss) : 0.8;
  return {
    weekly: Math.max(data.targetWeight, data.currentWeight - safeWeekly),
    monthly: Math.max(data.targetWeight, data.currentWeight - safeWeekly * 4),
    yearly: data.targetWeight
  };
}

function forecastWeights(currentWeight: number, targetWeight: number, weeklyLoss: number) {
  const weekly = weeklyLoss > 0 ? weeklyLoss : 0.8;
  const project = (days: number) => Math.max(targetWeight, currentWeight - (weekly / 7) * days);
  return { day30: project(30), day60: project(60), day90: project(90) };
}

function achievementList(data: AppData) {
  const weightLost = Math.max(0, data.initialWeight - data.currentWeight);
  const waterLiters = data.water.reduce((sum, entry) => sum + entry.amount, 0) / 1000;
  const photoMeals = data.meals.filter((meal) => meal.photo).length;
  return [
    { name: "Primeira refeicao registrada", done: data.meals.length >= 1 },
    { name: "Primeira semana completa", done: data.streak >= 7 },
    { name: "Primeiro mes completo", done: data.streak >= 30 },
    { name: "100 litros de agua", done: waterLiters >= 100 },
    { name: "100 fotos de refeicoes", done: photoMeals >= 100 },
    { name: "Primeiros 5 kg perdidos", done: weightLost >= 5 },
    { name: "Primeiros 10 kg perdidos", done: weightLost >= 10 },
    { name: "Primeiros 25 kg perdidos", done: weightLost >= 25 }
  ];
}

function specialMissionList(data: AppData) {
  const waterDays = new Set(data.water.map((entry) => entry.date)).size;
  const mealDays = new Set(data.meals.map((meal) => meal.date)).size;
  const weightLost = Math.max(0, data.initialWeight - data.currentWeight);
  return [
    { name: "Operacao Agua", progress: Math.min(100, Math.round((waterDays / 7) * 100)), text: "Bater agua por 7 dias" },
    { name: "Operacao Constancia", progress: Math.min(100, Math.round((mealDays / 30) * 100)), text: "Registrar refeicoes por 30 dias" },
    { name: "Operacao 10 kg", progress: Math.min(100, Math.round((weightLost / 10) * 100)), text: "Perder os primeiros 10 kg" },
    { name: "Operacao 100 kg", progress: data.currentWeight <= data.targetWeight ? 100 : Math.round(((data.initialWeight - data.currentWeight) / Math.max(1, data.initialWeight - data.targetWeight)) * 100), text: "Alcancar o peso final" }
  ];
}

function badgesFor(data: AppData) {
  const waterLiters = data.water.reduce((sum, entry) => sum + entry.amount, 0) / 1000;
  const photoMeals = data.meals.filter((meal) => meal.photo).length;
  return [
    { name: "Mestre da Agua", done: waterLiters >= 100 },
    { name: "Mestre do Registro", done: photoMeals >= 100 },
    { name: "Mestre da Consistencia", done: data.streak >= 30 },
    { name: "Sequencia de 100 dias", done: data.streak >= 100 },
    { name: "Missao Cumprida", done: data.currentWeight <= data.targetWeight }
  ];
}

function journeyMap(data: AppData) {
  const steps: Array<{ title: string; weight: number; done: boolean }> = [];
  for (let weight = data.initialWeight - 5; weight >= data.targetWeight; weight -= 5) {
    steps.push({ title: weight === data.targetWeight ? "Missao Final" : `Missao ${steps.length + 1}`, weight, done: data.currentWeight <= weight });
  }
  return steps;
}

function avatarState(data: AppData, rank: string) {
  const lost = Math.max(0, data.initialWeight - data.currentWeight);
  const stage = lost >= 25 ? 4 : lost >= 10 ? 3 : lost >= 5 ? 2 : 1;
  const items = ["Bota tática"];
  if (data.xp >= 500) items.push("Colete");
  if (data.streak >= 7) items.push("Patch de constancia");
  if (lost >= 10) items.push("Insignia de evolucao");
  return {
    stage,
    initials: rank.slice(0, 2).toUpperCase(),
    uniform: `Uniforme ${rank}`,
    description: stage >= 3 ? "Avatar mais leve, postura firme e novo equipamento." : "Avatar em treinamento, evoluindo com suas metas.",
    items
  };
}

function campaignMap(data: AppData) {
  const targets = [
    ["Base Inicial", data.initialWeight],
    ["Acampamento 1", 150],
    ["Acampamento 2", 140],
    ["Quartel General", 130],
    ["Missao Final", data.targetWeight]
  ] as const;
  return targets.map(([title, weight]) => ({ title, weight, done: data.currentWeight <= weight }));
}

function intelligenceInsights(data: AppData) {
  const waterByDay = groupCount(data.water, (entry) => entry.date, (entry) => entry.amount);
  const lowWaterDays = Object.values(waterByDay).filter((amount) => amount < data.waterGoalMl).length;
  const mealByDay = groupCount(data.meals, (meal) => meal.date, (meal) => meal.grams);
  const heavyDays = Object.values(mealByDay).filter((grams) => grams > 1000).length;
  const before20 = data.meals.filter((meal) => meal.name.toLowerCase().includes("janta") && meal.time < "20:00").length;
  return [
    lowWaterDays ? `Voce teve ${lowWaterDays} dia(s) com agua abaixo da meta.` : "Agua dentro da meta nos dias registrados.",
    heavyDays ? `${heavyDays} dia(s) passaram de 1.000 g registrados.` : "Porcoes dentro de uma faixa controlada nos registros.",
    before20 ? "Voce costuma cumprir mais metas quando janta antes das 20h." : "Registre o horario da janta para detectar padroes.",
    data.meals.length ? `Horario com mais registros: ${mostCommonHour(data.meals.map((meal) => meal.time))}h.` : "Registre refeicoes para revelar horarios de fome."
  ];
}

function groupCount<T>(items: T[], key: (item: T) => string, value: (item: T) => number) {
  return items.reduce<Record<string, number>>((acc, item) => {
    const itemKey = key(item);
    acc[itemKey] = (acc[itemKey] ?? 0) + value(item);
    return acc;
  }, {});
}

function mostCommonHour(times: string[]) {
  const counts = times.reduce<Record<string, number>>((acc, time) => {
    const hour = time.slice(0, 2);
    acc[hour] = (acc[hour] ?? 0) + 1;
    return acc;
  }, {});
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "--";
}

function widgetPreview(data: AppData, waterToday: number, plannedName: string, plannedTime: string) {
  const waterLeft = Math.max(0, data.waterGoalMl - waterToday);
  const dailyDone = Math.round((Object.values(data.checklistByDate[todayKey()] ?? {}).filter(Boolean).length / 6) * 100);
  return {
    small: `${waterLeft} ml de agua restantes`,
    medium: `${data.plannedMeals[0]?.name ?? plannedName} as ${data.plannedMeals[0]?.plannedTime ?? plannedTime} | ${data.currentWeight.toFixed(1)} kg`,
    large: `Missao diaria ${dailyDone}% completa`
  };
}

function exportTable(data: AppData) {
  const rows = ["tipo,data,hora,nome,valor,extra"];
  data.weights.forEach((entry) => rows.push(`peso,${entry.date},,peso,${entry.weight},kg`));
  data.water.forEach((entry) => rows.push(`agua,${entry.date},${entry.time},agua,${entry.amount},ml`));
  data.meals.forEach((meal) => rows.push(`refeicao,${meal.date},${meal.time},${meal.name},${meal.grams},${meal.calories ?? 0} kcal`));
  (data.symptoms ?? []).forEach((symptom) => rows.push(`sintoma,${symptom.date},${symptom.time},${symptom.text},${symptom.strong ? "forte" : "normal"},`));
  (data.checkups ?? []).forEach((entry) => rows.push(`checkup,${entry.date},,pressao ${entry.bloodPressure},${entry.glucose},glicemia; fc ${entry.heartRate}; ${entry.examNote}`));
  (data.sleeps ?? []).forEach((entry) => rows.push(`sono,${entry.date},${entry.sleptAt}-${entry.wokeAt},${entry.quality},${entry.hours},horas`));
  (data.watchEntries ?? []).forEach((entry) => rows.push(`relogio,${entry.date},,${entry.source},${entry.steps},passos; fc ${entry.heartRate}; exercicio ${entry.exerciseMinutes}`));
  return rows.join("\n");
}

function analyzeVoiceMeal(text: string) {
  const grams = text.toLowerCase().includes("hamburg") ? 620 : text.toLowerCase().includes("suco") ? 430 : 480;
  const analysis = analyzeMeal(grams, text);
  return { ...analysis, name: "Refeicao por voz", grams };
}

function jarvisMode(data: AppData, name: string, waterToday: number, remainingKg: number) {
  const firstName = name.split(" ")[0] || "operador";
  return [
    `Boa noite, ${firstName}. Faltam ${Math.max(0, data.waterGoalMl - waterToday)} ml de agua para completar sua missao de hoje.`,
    `Voce perdeu ${Math.max(0, data.initialWeight - data.currentWeight).toFixed(1)} kg desde o inicio da jornada.`,
    `Parabens. Restam ${remainingKg.toFixed(1)} kg para sua meta final.`
  ];
}

function legacyMode(data: AppData) {
  const unlocked = data.currentWeight <= data.targetWeight;
  return {
    unlocked,
    title: unlocked ? "Modo legado desbloqueado" : "Modo legado bloqueado",
    message: unlocked ? "Missao concluida. Patente maxima, certificado e medalha permanente liberados." : "Alcance o peso-meta para desbloquear o legado completo."
  };
}

function personalRecords(data: AppData) {
  const waterByDay = groupCount(data.water, (entry) => entry.date, (entry) => entry.amount);
  const mealsByDay = groupCount(data.meals, (meal) => meal.date, () => 1);
  return {
    longestStreak: Math.max(data.records?.longestStreak ?? 0, data.streak),
    maxWaterMl: Math.max(data.records?.maxWaterMl ?? 0, ...Object.values(waterByDay), 0),
    maxMonthlyLoss: Math.max(data.records?.maxMonthlyLoss ?? 0, averageWeightLoss(data.weights, 30)),
    maxMealsDay: Math.max(data.records?.maxMealsDay ?? 0, ...Object.values(mealsByDay), 0)
  };
}

function timelineEvents(data: AppData) {
  const lost = Math.max(0, data.initialWeight - data.currentWeight);
  const start = new Date(data.startedAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
  return [
    { date: start, label: `Inicio - ${data.initialWeight} kg`, done: true },
    { date: "20/07", label: "Primeiros 10 kg", done: lost >= 10 },
    { date: "25/08", label: "Primeiros 20 kg", done: lost >= 20 },
    { date: "10/10", label: "Primeiros 30 kg", done: lost >= 30 },
    { date: "Meta Final", label: `${data.targetWeight} kg`, done: data.currentWeight <= data.targetWeight }
  ];
}

function interactiveMapSteps(data: AppData) {
  return [
    ["Base Inicial", 160],
    ["Acampamento Alpha", 150],
    ["Acampamento Bravo", 140],
    ["Quartel Charlie", 130],
    ["Fortaleza Delta", 120],
    ["Operacao Final", 110],
    ["Objetivo Concluido", 100]
  ].map(([name, weight]) => ({ name: String(name), weight: Number(weight), done: data.currentWeight <= Number(weight) }));
}

function simulateGoalDate(currentWeight: number, targetWeight: number, kgPerMonth: number) {
  if (currentWeight <= targetWeight) return "meta atingida";
  const months = Math.ceil((currentWeight - targetWeight) / Math.max(0.1, kgPerMonth));
  const date = new Date();
  date.setMonth(date.getMonth() + months);
  return date.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" });
}

function planningAdvice(plan: string) {
  const advice: Record<string, string> = {
    Descansar: "Hoje reduza a friccao: agua visivel, refeicoes simples e sono como prioridade.",
    Trabalhar: "Use lembretes curtos para agua e registre refeicoes antes de voltar ao ritmo.",
    Sair: "Antes de sair, planeje agua e uma refeicao segura para nao decidir no impulso.",
    "Comer fora": "Olhe o prato antes de repetir. Prefira registrar gramas aproximadas e seguir sem culpa.",
    "Ficar em casa": "Ambiente controlado: deixe favoritos saudaveis faceis e proibidos fora de vista."
  };
  return advice[plan] ?? advice["Ficar em casa"];
}

function hallOfFame(data: AppData, rank: string, achievements: Array<{ done: boolean }>, missions: Array<{ progress: number }>) {
  return {
    rank,
    achievements: achievements.filter((item) => item.done).length,
    rewards: (data.shopRewards ?? []).filter((reward) => reward.claimed).length,
    missions: missions.filter((mission) => mission.progress >= 100).length + Object.values(data.checklistByDate).filter((checklist) => Object.values(checklist).filter(Boolean).length >= 5).length
  };
}

function parseVoiceCommand(text: string): { type: "water"; amount: number } | { type: "weight"; weight: number } | { type: "meal" } {
  const lower = text.toLowerCase();
  const number = Number(lower.match(/\d+/)?.[0] ?? 0);
  if (lower.includes("agua") || lower.includes("água") || lower.includes("ml")) return { type: "water", amount: number || 300 };
  if (lower.includes("peso") || lower.includes("quilo")) return { type: "weight", weight: number || 0 };
  return { type: "meal" };
}

function memoriesOfJourney(data: AppData) {
  return [
    { label: "Primeiro peso", value: `${data.initialWeight} kg` },
    { label: "Primeira foto", value: (data.bodyPhotos ?? [])[0]?.date ?? "Ainda nao registrada" },
    { label: "Primeiro objetivo", value: (data.objectives ?? [])[0]?.text ?? "Ainda nao registrado" },
    { label: "Primeira recompensa", value: (data.shopRewards ?? [])[0]?.name ?? "Ainda nao cadastrada" },
    { label: "Maior sequencia", value: `${data.streak} dias` }
  ];
}

function milestoneSystemList(data: AppData) {
  const lost = Math.max(0, data.initialWeight - data.currentWeight);
  return [5, 10, 15, 20, 25, 50].map((kg) => ({ kg, done: lost >= kg }));
}

function worldMapProgress(weightLost: number) {
  const km = Math.round(weightLost * 10);
  const cities = [
    ["Base local", 0],
    ["Ponto Alpha", 50],
    ["Cidade Bravo", 100],
    ["Capital Delta", 250],
    ["Objetivo Global", 500]
  ] as const;
  const city = [...cities].reverse().find(([, distance]) => km >= distance)?.[0] ?? "Base local";
  return { km, city, progress: Math.min(100, Math.round((km / 500) * 100)) };
}

function dataCenterStats(data: AppData, weekly: number, monthly: number) {
  const avgWater = data.water.length ? data.water.reduce((sum, entry) => sum + entry.amount, 0) / Math.max(1, new Set(data.water.map((entry) => entry.date)).size) : 0;
  const monthlyWeight = data.weights.length ? data.weights.slice(-4).reduce((sum, entry) => sum + entry.weight, 0) / Math.min(4, data.weights.length) : data.currentWeight;
  const bestMonthLabel = data.weights.length ? data.weights[data.weights.length - 1].date.slice(0, 7) : "Mes atual";
  return { monthlyWeight, avgWater, compliance: monthly, bestWeek: weekly, bestMonthLabel };
}

function predictionSystemText(data: AppData, weeklyLoss: number) {
  const weekly = weeklyLoss > 0 ? weeklyLoss : 0.8;
  const p = (months: number) => Math.max(data.targetWeight, data.currentWeight - weekly * 4 * months).toFixed(1);
  return `Se continuar neste ritmo:\n\n1 mes: ${p(1)} kg\n2 meses: ${p(2)} kg\n3 meses: ${p(3)} kg\nMeta final estimada: ${predictGoalDate(data.currentWeight, data.targetWeight, weekly)}`;
}

function finalMissionState(data: AppData) {
  const unlocked = data.currentWeight <= data.targetWeight;
  return {
    unlocked,
    title: unlocked ? "Final da missao desbloqueado" : "Final da missao em andamento",
    items: unlocked
      ? ["Patente maxima", "Trofeu digital", "Relatorio completo", "Linha antes/depois", "Certificado", "Sala da Fama permanente"]
      : ["Continue ate o peso-meta para liberar o pacote final"]
  };
}

function globalSearch(data: AppData, query: string) {
  if (!query.trim()) return [];
  const q = query.toLowerCase();
  const rows = [
    ...data.meals.map((meal) => `Refeicao ${meal.date}: ${meal.name} ${meal.grams}g`),
    ...data.water.map((entry) => `Agua ${entry.date}: ${entry.amount}ml`),
    ...data.weights.map((entry) => `Peso ${entry.date}: ${entry.weight}kg`),
    ...(data.symptoms ?? []).map((entry) => `Sintoma ${entry.date}: ${entry.text}`),
    ...(data.checkups ?? []).map((entry) => `Check-up ${entry.date}: pressao ${entry.bloodPressure} glicemia ${entry.glucose}`),
    ...(data.sleeps ?? []).map((entry) => `Sono ${entry.date}: ${entry.hours}h ${entry.quality}`),
    ...(data.objectives ?? []).map((objective) => `Objetivo: ${objective.text}`)
  ];
  return rows.filter((row) => row.toLowerCase().includes(q));
}

function seasonalEventList(data: AppData) {
  if (!data.settings?.seasonalEvents) return ["Eventos sazonais desligados nas configuracoes."];
  return [
    "Evento secreto: registre agua por 3 dias para desbloquear uma insignia.",
    data.streak >= 7 ? "Easter egg liberado: Semana Blindada." : "Easter egg oculto: mantenha 7 dias de sequencia."
  ];
}

function nextCampaignTarget(data: AppData) {
  return campaignMap(data).find((step) => !step.done)?.weight ?? data.targetWeight;
}

function trophyRoomItems(data: AppData, achievements: Array<{ name: string; done: boolean }>, missions: Array<{ name: string; progress: number }>) {
  return [
    { name: "Medalhas", detail: `${achievements.filter((item) => item.done).length}/${achievements.length}`, done: achievements.some((item) => item.done) },
    { name: "Recorde de sequencia", detail: `${data.streak} dias`, done: data.streak >= 3 },
    { name: "Missoes especiais", detail: `${missions.filter((item) => item.progress >= 100).length}/${missions.length}`, done: missions.some((item) => item.progress >= 100) },
    { name: "Caixas abertas", detail: `${(data.openedRewardBoxes ?? []).length}`, done: (data.openedRewardBoxes ?? []).length > 0 }
  ];
}

function specialTitlesFor(data: AppData) {
  const waterLiters = data.water.reduce((sum, entry) => sum + entry.amount, 0) / 1000;
  const photoMeals = data.meals.filter((meal) => meal.photo).length;
  const lost = Math.max(0, data.initialWeight - data.currentWeight);
  return [
    { name: "Guardiao da Agua", done: waterLiters >= 30 },
    { name: "Mestre dos Registros", done: photoMeals >= 30 },
    { name: "Inabalavel", done: data.streak >= 30 },
    { name: "Veterano da Consistencia", done: data.streak >= 100 },
    { name: "Mestre da Evolucao", done: lost >= 25 }
  ];
}

function milestoneState(data: AppData) {
  const lost = Math.max(0, data.initialWeight - data.currentWeight);
  const milestone = [50, 25, 10, 5].find((value) => lost >= value);
  if (!milestone) return { title: "Primeiro marco em andamento", message: "O certificado libera ao perder 5 kg.", certificate: "Continue a missao." };
  return {
    title: `${milestone} kg eliminados`,
    message: "Marco conquistado com constancia. Sem exageros, sem punicao.",
    certificate: `Certificado Meta Prato - ${milestone} kg`
  };
}

function reflectionTip(value?: string) {
  const tips: Record<string, string> = {
    Agua: "Deixe uma garrafa visivel e divida a meta em pequenos blocos.",
    Fome: "Planeje a proxima refeicao com calma e registre antes de repetir.",
    "Vontade de doce": "Espere alguns minutos, beba agua e escolha uma porcao controlada se ainda fizer sentido.",
    Cansaco: "Hoje foque no basico: agua, registro e descanso.",
    Ansiedade: "Respire, sente um pouco e evite decidir comida no impulso.",
    Outro: "Anote o padrao e volte para uma acao simples na proxima refeicao."
  };
  return value ? tips[value] : "Escolha uma opcao para receber uma dica simples.";
}

function sleepHours(sleptAt: string, wokeAt: string) {
  const [sh = 0, sm = 0] = sleptAt.split(":").map(Number);
  const [wh = 0, wm = 0] = wokeAt.split(":").map(Number);
  const start = sh * 60 + sm;
  let end = wh * 60 + wm;
  if (end <= start) end += 1440;
  return Math.round(((end - start) / 60) * 10) / 10;
}

function sleepAnalytics(data: AppData) {
  const sleeps = data.sleeps ?? [];
  const average = sleeps.length ? sleeps.reduce((sum, item) => sum + item.hours, 0) / sleeps.length : 0;
  const lastSleep = sleeps[sleeps.length - 1];
  return { average, quality: lastSleep?.quality ?? "Sem registro" };
}

function moodAnalytics(data: AppData) {
  const moods = Object.values(data.moodByDate ?? {});
  const counts = moods.reduce<Record<string, number>>((acc, mood) => {
    acc[mood] = (acc[mood] ?? 0) + 1;
    return acc;
  }, {});
  const common = Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "Sem dados";
  return { common, total: moods.length };
}

function challengesFor(data: AppData) {
  const waterDays = new Set(data.water.map((entry) => entry.date)).size;
  const mealDays = new Set(data.meals.map((meal) => meal.date)).size;
  const photos = data.meals.filter((meal) => meal.photo).length;
  const lost = Math.max(0, data.initialWeight - data.currentWeight);
  return [
    { name: "Desafio Agua", progress: Math.min(100, Math.round((waterDays / 7) * 100)), text: "7 dias completos" },
    { name: "Desafio Constancia", progress: Math.min(100, Math.round((mealDays / 30) * 100)), text: "30 dias registrando refeicoes" },
    { name: "Desafio Fotografo", progress: Math.min(100, photos), text: "100 fotos de pratos" },
    { name: "Desafio Evolucao", progress: Math.min(100, Math.round((lost / 10) * 100)), text: "Perder os primeiros 10 kg" }
  ];
}

function collectiblesFor(data: AppData) {
  return [
    { name: "Insignia Agua", done: new Set(data.water.map((entry) => entry.date)).size >= 7 },
    { name: "Medalha Registro", done: data.meals.length >= 30 },
    { name: "Banner Sargento", done: data.xp >= 1200 },
    { name: "Moldura de Perfil", done: (data.coins ?? 0) >= 100 },
    { name: "Titulo Especial", done: data.streak >= 30 }
  ];
}

function analyticsPanel(data: AppData) {
  const weeklyWeight = data.weights.length ? data.weights.slice(-7).reduce((sum, entry) => sum + entry.weight, 0) / Math.min(7, data.weights.length) : data.currentWeight;
  const waterDays = Math.max(1, new Set(data.water.map((entry) => entry.date)).size);
  const mealDays = Math.max(1, new Set(data.meals.map((meal) => meal.date)).size);
  const avgWater = data.water.reduce((sum, entry) => sum + entry.amount, 0) / waterDays;
  const avgMeals = data.meals.length / mealDays;
  const commonHour = mostCommonHour(data.meals.map((meal) => meal.time));
  const scores = Object.values(data.checklistByDate).map((checklist) => Object.values(checklist).filter(Boolean).length / 6);
  const compliance = scores.length ? Math.round((scores.reduce((sum, score) => sum + score, 0) / scores.length) * 100) : 0;
  return { weeklyWeight, avgWater, avgMeals, commonHour, compliance };
}

function knowledgeArticles() {
  return [
    { title: "O que e proteina", text: "Proteina ajuda na manutencao de massa muscular e saciedade. Este app apenas organiza registros." },
    { title: "O que e carboidrato", text: "Carboidratos sao fonte de energia. O objetivo aqui e controle e consistencia, nao restricao extrema." },
    { title: "Hidratacao", text: "Agua ajuda na rotina e no bem-estar. A meta padrao do app e 2.300 ml." },
    { title: "Leitura de rotulos", text: "Observe porcao, calorias, proteinas, carboidratos, gorduras e sodio." },
    { title: "Metas do app", text: "As metas sao estimativas locais para acompanhamento. Nao substituem profissional." }
  ];
}

function missionOfDay(data: AppData, waterToday: number, daily: number) {
  const checklist = getTodayChecklist(data);
  const photoMeals = data.meals.filter((meal) => meal.date === todayKey() && meal.photo).length;
  const items = [
    { text: `Beber ${data.waterGoalMl} ml de agua`, done: waterToday >= data.waterGoalMl, progress: Math.min(100, Math.round((waterToday / data.waterGoalMl) * 100)) },
    { text: "Registrar refeicoes", done: checklist.mealRegistered, progress: checklist.mealRegistered ? 100 : 30 },
    { text: "Tirar foto dos pratos", done: checklist.platePhoto || photoMeals > 0, progress: checklist.platePhoto || photoMeals > 0 ? 100 : 20 },
    { text: "Cumprir a meta do dia", done: daily >= 80, progress: daily }
  ];
  return { items, completed: items.every((item) => item.done) };
}

function monthlyMissionFor(data: AppData) {
  const mealDays = new Set(data.meals.map((meal) => meal.date)).size;
  const waterDays = new Set(data.water.map((entry) => entry.date)).size;
  const lost = Math.max(0, data.initialWeight - data.currentWeight);
  return [
    { text: "Registrar refeicoes por 25 dias", progress: Math.min(100, Math.round((mealDays / 25) * 100)), reward: "Medalha exclusiva + moedas" },
    { text: "Cumprir agua por 20 dias", progress: Math.min(100, Math.round((waterDays / 20) * 100)), reward: "Titulo Guardiao da Agua" },
    { text: "Perder 5 kg no ciclo", progress: Math.min(100, Math.round((lost / 5) * 100)), reward: "Certificado mensal" }
  ];
}

function inventoryFor(data: AppData, achievements: Array<{ name: string; done: boolean }>, titles: Array<{ name: string; done: boolean }>, rankName: string) {
  return [
    ...achievements.map((item) => ({ type: "Medalha", name: item.name, unlocked: item.done })),
    ...titles.map((item) => ({ type: "Titulo", name: item.name, unlocked: item.done })),
    { type: "Patente", name: rankName, unlocked: true },
    { type: "Certificado", name: "Primeiros 5 kg", unlocked: Math.max(0, data.initialWeight - data.currentWeight) >= 5 },
    { type: "Tema", name: data.settings?.theme ?? "military", unlocked: true }
  ].slice(0, 18);
}

function advancedInsightCenter(data: AppData) {
  const commonHour = mostCommonHour(data.meals.map((meal) => meal.time));
  const waterAverage = analyticsPanel(data).avgWater;
  const bestDay = bestWeekday(data);
  const bestFood = favoriteFoods(data)[0] ?? "sem padrao ainda";
  return [
    `Voce cumpre mais metas em ${bestDay}.`,
    `Sua media de agua e ${waterAverage.toFixed(0)} ml por dia registrado.`,
    `Seu horario mais comum de refeicao e ${commonHour}h.`,
    `Alimento mais frequente: ${bestFood}.`,
    `Perfil detectado: ${personalityProfile(data)}.`
  ];
}

function riskRadarFor(data: AppData, waterToday: number) {
  const alerts = safetyAlerts(data);
  const lastMealDate = data.meals[data.meals.length - 1]?.date;
  if (waterToday < data.waterGoalMl * 0.45) alerts.push("Sua hidratacao esta baixa hoje. Vamos voltar para a missao de agua?");
  if (!lastMealDate || daysBetween(new Date(`${lastMealDate}T12:00:00`), new Date()) >= 2) alerts.push("Poucos registros recentes. Registre uma refeicao simples para retomar a sequencia.");
  if (!alerts.length) alerts.push("Radar limpo: nenhum risco forte detectado agora.");
  return alerts;
}

function futureSelfForecast(data: AppData, weeklyLoss: number) {
  const weekly = weeklyLoss > 0 ? weeklyLoss : 0.8;
  const project = (weeks: number) => `${Math.max(data.targetWeight, data.currentWeight - weekly * weeks).toFixed(1)} kg`;
  return [
    { label: "Voce atual", value: `${data.currentWeight.toFixed(1)} kg` },
    { label: "Em 30 dias", value: project(4) },
    { label: "Em 90 dias", value: project(12) },
    { label: "Na meta final", value: `${data.targetWeight.toFixed(1)} kg` }
  ];
}

function lifeOsModules(data: AppData) {
  return [
    { name: "Peso e alimentacao", status: `${data.meals.length} refeicoes`, active: true },
    { name: "Agua", status: `${(data.water.reduce((sum, item) => sum + item.amount, 0) / 1000).toFixed(1)} L`, active: data.water.length > 0 },
    { name: "Sono", status: `${(data.sleeps ?? []).length} registros`, active: (data.sleeps ?? []).length > 0 },
    { name: "Estudos", status: "modulo de vida preparado", active: false },
    { name: "Financas", status: `R$ ${data.homeSavings ?? 0} economizados`, active: (data.homeSavings ?? 0) > 0 },
    { name: "Objetivos pessoais", status: `${(data.objectives ?? []).length} missoes`, active: true },
    { name: "Diario", status: `${Object.keys(data.dailyFeedback ?? {}).length} entradas`, active: Object.keys(data.dailyFeedback ?? {}).length > 0 }
  ];
}

function biographyWriter(data: AppData, name: string, rankName: string) {
  const lost = Math.max(0, data.initialWeight - data.currentWeight);
  const lines = [
    `Dia 1: ${name} iniciou sua missao aos ${data.initialWeight} kg.`,
    `Hoje: alcancou ${data.currentWeight.toFixed(1)} kg e a patente ${rankName}.`,
    `Registro: ${data.meals.length} refeicoes, ${data.water.length} aguas, ${(data.bodyPhotos ?? []).length} fotos corporais.`,
    lost >= 10 ? "Marco: primeiros 10 kg superados." : `Proximo capitulo: faltam ${(10 - lost).toFixed(1)} kg para o marco de 10 kg.`,
    data.currentWeight <= data.targetWeight ? "Dia final: missao concluida e Hall da Fama liberado." : "A campanha continua com constancia diaria."
  ];
  return lines;
}

function evolutionIsland(data: AppData) {
  const lost = Math.max(0, data.initialWeight - data.currentWeight);
  if (lost >= 60 || data.currentWeight <= data.targetWeight) return { name: "Reino Lendario", description: "A ilha chegou ao nivel maximo da jornada.", next: "Hall da Fama permanente liberado." };
  if (lost >= 30) return { name: "Capital", description: "Sua ilha virou uma capital de conquistas.", next: "Proximo: Reino Lendario." };
  if (lost >= 15) return { name: "Cidade", description: "Novas estruturas apareceram com a consistencia.", next: "Proximo: Capital aos 30 kg perdidos." };
  if (lost >= 5) return { name: "Vila", description: "Primeira expansao construida.", next: "Proximo: Cidade aos 15 kg perdidos." };
  return { name: "Acampamento", description: "Toda grande jornada comeca em uma base simples.", next: "Proximo: Vila aos 5 kg perdidos." };
}

function virtualPet(data: AppData, rankName: string) {
  const stages = ["Ovo", "Recruta", "Soldado", "Capitao", "General"];
  const index = Math.min(stages.length - 1, Math.floor(data.streak / 15));
  return {
    name: "Mascote de Missao",
    stage: stages[index],
    message: data.streak > 0 ? `Comemorando ${data.streak} dia(s) de sequencia.` : "Pronto para evoluir com sua primeira missao.",
    bonus: `Roupas e animacoes seguem sua patente: ${rankName}.`
  };
}

function skillTreeFor(data: AppData) {
  const waterLiters = data.water.reduce((sum, entry) => sum + entry.amount, 0) / 1000;
  const photoMeals = data.meals.filter((meal) => meal.photo).length;
  const lost = Math.max(0, data.initialWeight - data.currentWeight);
  return [
    { name: "Mestre da Agua", level: Math.min(5, Math.floor(waterLiters / 20)) },
    { name: "Mestre dos Registros", level: Math.min(5, Math.floor(photoMeals / 10)) },
    { name: "Mestre da Consistencia", level: Math.min(5, Math.floor(data.streak / 7)) },
    { name: "Mestre das Sequencias", level: Math.min(5, Math.floor(data.streak / 20)) },
    { name: "Mestre das Missoes", level: Math.min(5, Math.floor(lost / 5)) }
  ];
}

function secretMissionsFor(data: AppData) {
  const waterLiters = data.water.reduce((sum, entry) => sum + entry.amount, 0) / 1000;
  const photoMeals = data.meals.filter((meal) => meal.photo).length;
  const lost = Math.max(0, data.initialWeight - data.currentWeight);
  return [
    { name: "365 dias de missao", done: data.streak >= 365 },
    { name: "1.000 litros de agua", done: waterLiters >= 1000 },
    { name: "1.000 fotos de pratos", done: photoMeals >= 1000 },
    { name: "50 kg perdidos", done: lost >= 50 },
    { name: "100 dias consecutivos", done: data.streak >= 100 }
  ];
}

function favoriteFoods(data: AppData) {
  const counts = data.meals.flatMap((meal) => meal.foods?.length ? meal.foods : [meal.name]).reduce<Record<string, number>>((acc, food) => {
    acc[food] = (acc[food] ?? 0) + 1;
    return acc;
  }, {});
  return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([name]) => name);
}

function bestWeekday(data: AppData) {
  const names = ["domingo", "segunda", "terca", "quarta", "quinta", "sexta", "sabado"];
  const counts = Object.entries(data.checklistByDate ?? {}).reduce<Record<string, number>>((acc, [date, checklist]) => {
    const score = Object.values(checklist).filter(Boolean).length;
    const day = names[new Date(`${date}T12:00:00`).getDay()];
    acc[day] = (acc[day] ?? 0) + score;
    return acc;
  }, {});
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "dias com registro";
}

function personalityProfile(data: AppData) {
  if (data.streak >= 30) return "Persistente";
  if ((data.bodyPhotos ?? []).length >= 5) return "Cronista";
  if (data.water.length >= data.meals.length) return "Guardiao da Agua";
  if ((data.objectives ?? []).length >= 4) return "Planejador";
  return "Explorador";
}

function seasonPassReward(tier: number) {
  const rewards: Record<number, string> = {
    1: "Medalha inicial",
    10: "Avatar exclusivo",
    20: "Tema novo",
    30: "Moldura rara",
    50: "Titulo lendario"
  };
  return rewards[tier] ?? "Recompensa cosmetica";
}

function storyChapters(data: AppData) {
  const lost = Math.max(0, data.initialWeight - data.currentWeight);
  return [
    { title: "Capitulo 1 - O Inicio", done: true, reward: "Cinematica inicial" },
    { title: "Capitulo 2 - Primeiros 10 kg", done: lost >= 10, reward: "Medalha + certificado" },
    { title: "Capitulo 3 - Primeiros 25 kg", done: lost >= 25, reward: "Titulo raro" },
    { title: "Capitulo 4 - Transformacao", done: lost >= 50, reward: "Trofeu digital" },
    { title: "Capitulo Final - Missao Concluida", done: data.currentWeight <= data.targetWeight, reward: "Hall da Fama" }
  ];
}

function buildReportHtml(data: AppData, patient: Patient) {
  const esc = (value: unknown) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[char] ?? char));
  const meals = data.meals.slice(-10).map((meal) => `<li>${esc(meal.date)} ${esc(meal.time)} - ${esc(meal.name)} - ${meal.grams} g - ${meal.calories ?? 0} kcal</li>`).join("");
  const symptoms = (data.symptoms ?? []).slice(-10).map((item) => `<li>${esc(item.date)} ${esc(item.time)} - ${esc(item.text)} ${item.strong ? "<strong>FORTES</strong>" : ""}</li>`).join("");
  const measures = (data.bodyMeasures ?? []).slice(-5).map((item) => `<li>${esc(item.date)} - cintura ${item.waist} cm, peito ${item.chest} cm, braco ${item.arm} cm, coxa ${item.thigh} cm, pescoco ${item.neck} cm</li>`).join("");
  const checkups = (data.checkups ?? []).slice(-8).map((item) => `<li>${esc(item.date)} - pressao ${esc(item.bloodPressure)}, glicemia ${item.glucose}, frequencia cardiaca ${item.heartRate}. ${esc(item.examNote)}</li>`).join("");
  const sleeps = (data.sleeps ?? []).slice(-8).map((item) => `<li>${esc(item.date)} - ${item.hours}h, qualidade ${esc(item.quality)}, ${esc(item.sleptAt)} ate ${esc(item.wokeAt)}</li>`).join("");
  const photos = (data.bodyPhotos ?? []).slice(-4).map((item) => `<figure><img src="${item.image}" /><figcaption>${esc(item.date)} - ${esc(item.note)}</figcaption></figure>`).join("");
  return `<!doctype html><html><head><meta charset="utf-8"><title>Relatorio Meta Prato</title><style>
    body{font-family:Arial,sans-serif;color:#172016;padding:24px} h1{color:#49651f} section{page-break-inside:avoid;margin:18px 0;padding:14px;border:1px solid #cad6be;border-radius:8px} img{max-width:180px;border-radius:8px;margin:8px} figure{display:inline-block;vertical-align:top} li{margin:6px 0}
  </style></head><body>
    <h1>Relatorio Meta Prato</h1>
    <p>Paciente: ${esc(patient.name)} | Email: ${esc(patient.email)}</p>
    <section><h2>Peso e evolucao</h2><p>Peso atual: ${data.currentWeight} kg | Meta: ${data.targetWeight} kg | Agua diaria: ${data.waterGoalMl} ml | XP: ${data.xp}</p></section>
    <section><h2>Refeicoes recentes</h2><ul>${meals || "<li>Sem refeicoes registradas.</li>"}</ul></section>
    <section><h2>Sintomas</h2><ul>${symptoms || "<li>Sem sintomas registrados.</li>"}</ul></section>
    <section><h2>Check-up</h2><ul>${checkups || "<li>Sem check-ups registrados.</li>"}</ul></section>
    <section><h2>Sono</h2><ul>${sleeps || "<li>Sem sono registrado.</li>"}</ul></section>
    <section><h2>Medidas</h2><ul>${measures || "<li>Sem medidas registradas.</li>"}</ul></section>
    <section><h2>Fotos</h2>${photos || "<p>Sem fotos corporais.</p>"}</section>
    <p>Este app e auxiliar. Nao substitui medico ou nutricionista.</p>
  </body></html>`;
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <div className={compact ? "brand compact" : "brand"}>
      <span className="brand-mark">MP</span>
      <strong>Meta Prato</strong>
    </div>
  );
}

function Panel({ title, children, className = "", id }: { title: string; children: React.ReactNode; className?: string; id?: string }) {
  return (
    <section className={`glass-panel ${className}`} id={id}>
      <h2>{title}</h2>
      {children}
    </section>
  );
}

function SectionTitle({ title }: { title: string }) {
  return <h2 className="section-title"><span>{title}</span></h2>;
}

function StatCard({ title, value, caption, progress, spark }: { title: string; value: string; caption?: string; progress?: number; spark?: boolean }) {
  return (
    <article className="stat-card">
      <p>{title}</p>
      <strong>{value}</strong>
      {caption ? <small>{caption}</small> : null}
      {typeof progress === "number" ? <ProgressBar value={progress} /> : null}
      {spark ? <SparkLine /> : null}
    </article>
  );
}

function SparkLine() {
  return (
    <svg className="spark" viewBox="0 0 120 42" preserveAspectRatio="none" aria-hidden="true">
      <polyline points="0,31 12,28 24,30 36,22 48,26 60,15 72,18 84,8 96,12 108,3 120,7" />
    </svg>
  );
}

function CircleProgress({ value, label }: { value: number; label: string }) {
  const safe = Math.max(0, Math.min(100, value));
  return (
    <div className="circle-progress" style={{ "--value": `${safe * 3.6}deg` } as React.CSSProperties}>
      <div><strong>{safe}%</strong></div>
      <span>{label}</span>
    </div>
  );
}

function Metric({ label, value, note }: { label: string; value: string; note: string }) {
  return (
    <div className="mini-metric">
      <span>{label}</span>
      <strong>{value}</strong>
      <small>{note}</small>
    </div>
  );
}

function Mission({ done, text }: { done: boolean; text: string }) {
  return (
    <div className="mission-row">
      <span className={done ? "tick on" : "tick"} />
      <p>{text}</p>
      <small>{done ? "OK" : "0/1"}</small>
    </div>
  );
}

function FlowPhone({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <article className="phone-frame">
      <p>{title}</p>
      <div className="phone-screen">{children}</div>
    </article>
  );
}

function RewardPanel({
  unlocked,
  title,
  value,
  examples,
  warning,
  onChange
}: {
  unlocked: boolean;
  title: string;
  value: string;
  examples: string[];
  warning: string;
  onChange: (value: string) => void;
}) {
  return (
    <article className={unlocked ? "reward-card unlocked" : "reward-card"}>
      <h3>{unlocked ? title : "Missao em andamento"}</h3>
      <p>{warning}</p>
      <input value={value} onChange={(event) => onChange(event.target.value)} />
      <div>
        {examples.map((example) => (
          <button key={example} onClick={() => onChange(example)}>{example}</button>
        ))}
      </div>
      <button className="claim-button">{unlocked ? "Resgatar recompensa" : "Registrar recompensa"}</button>
    </article>
  );
}

function WeightChart({ entries }: { entries: WeightEntry[] }) {
  const chartEntries = entries.length >= 2 ? entries : [
    { id: "1", date: "16/05", weight: 160 },
    { id: "2", date: "23/05", weight: 158 },
    { id: "3", date: "30/05", weight: 156 },
    { id: "4", date: "06/06", weight: 153 },
    { id: "5", date: "13/06", weight: 150 },
    { id: "6", date: "Hoje", weight: 145 }
  ];
  const weights = chartEntries.map((entry) => entry.weight);
  const min = Math.min(...weights) - 1;
  const max = Math.max(...weights) + 1;
  const points = chartEntries
    .map((entry, index) => {
      const x = (index / (chartEntries.length - 1)) * 100;
      const y = 100 - ((entry.weight - min) / (max - min)) * 100;
      return `${x},${y}`;
    })
    .join(" ");

  return (
    <svg className="weight-chart" viewBox="0 0 100 100" preserveAspectRatio="none" role="img" aria-label="Grafico de evolucao do peso">
      <g className="grid-lines">
        <line x1="0" x2="100" y1="25" y2="25" />
        <line x1="0" x2="100" y1="50" y2="50" />
        <line x1="0" x2="100" y1="75" y2="75" />
      </g>
      <polyline points={points} />
      {points.split(" ").map((point) => {
        const [cx, cy] = point.split(",");
        return <circle key={point} cx={cx} cy={cy} r="2.3" />;
      })}
    </svg>
  );
}

function buildWaterReminders(wakeTime?: string, sleepTime = "23:00") {
  const wake = wakeTime ?? "07:00";
  const [wakeHour, wakeMinute] = wake.split(":").map(Number);
  const [sleepHour, sleepMinute] = sleepTime.split(":").map(Number);
  const start = wakeHour * 60 + wakeMinute;
  let end = sleepHour * 60 + sleepMinute;
  if (end <= start) end += 24 * 60;
  const step = (end - start) / 4;
  return [1, 2, 3].map((slot) => {
    const minutes = Math.round(start + step * slot) % (24 * 60);
    const hour = Math.floor(minutes / 60).toString().padStart(2, "0");
    const minute = (minutes % 60).toString().padStart(2, "0");
    return `${hour}:${minute}`;
  });
}
