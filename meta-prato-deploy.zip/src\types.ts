export type Meal = {
  id: string;
  date: string;
  time: string;
  photo?: string;
  name: string;
  grams: number;
  foods?: string[];
  calories?: number;
  protein?: number;
  carbs?: number;
  fat?: number;
  aiMessage?: string;
  note: string;
  withinGoal: boolean;
};

export type BarcodeItem = {
  id: string;
  date: string;
  code: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
};

export type WeightEntry = {
  id: string;
  date: string;
  weight: number;
};

export type WaterEntry = {
  id: string;
  date: string;
  time: string;
  amount: number;
};

export type PlannedMeal = {
  id: string;
  name: string;
  plannedTime: string;
};

export type ChecklistState = {
  mealRegistered: boolean;
  platePhoto: boolean;
  water: boolean;
  noRepeat: boolean;
  withinGoal: boolean;
  weightRegistered: boolean;
};

export type RewardState = {
  weekly: string;
  monthly: string;
  weeklyClaimedKey?: string;
  monthlyClaimedKey?: string;
};

export type ShopReward = {
  id: string;
  name: string;
  cost: number;
  claimed?: boolean;
};

export type SymptomEntry = {
  id: string;
  date: string;
  time: string;
  text: string;
  strong?: boolean;
};

export type BodyPhoto = {
  id: string;
  date: string;
  image: string;
  note: string;
  angle?: "front" | "side" | "back";
};

export type BodyMeasure = {
  id: string;
  date: string;
  waist: number;
  chest: number;
  arm: number;
  thigh: number;
  neck: number;
};

export type MarketItem = {
  id: string;
  name: string;
  type: "shopping" | "favorite" | "blocked";
  done?: boolean;
};

export type HealthProfile = {
  medicines: string;
  allergies: string;
  conditions: string;
};

export type Habit = {
  id: string;
  name: string;
  doneDates: string[];
};

export type TravelMode = {
  active: boolean;
  location: string;
  timeShift: number;
};

export type PersonalObjective = {
  id: string;
  text: string;
  done?: boolean;
};

export type Season = {
  id: string;
  name: string;
  targetLoss: number;
  reward: string;
};

export type PersonalRecords = {
  longestStreak: number;
  maxWaterMl: number;
  maxMonthlyLoss: number;
  maxMealsDay: number;
};

export type AppSettings = {
  theme: "military" | "future" | "corporate" | "minimal" | "blackout";
  haptics: boolean;
  smartNotifications: boolean;
  cloudBackup: boolean;
  appleHealth: boolean;
  googleFit: boolean;
  seasonalEvents: boolean;
};

export type CheckupEntry = {
  id: string;
  date: string;
  bloodPressure: string;
  glucose: number;
  heartRate: number;
  examNote: string;
};

export type SleepEntry = {
  id: string;
  date: string;
  sleptAt: string;
  wokeAt: string;
  hours: number;
  quality: string;
};

export type WatchEntry = {
  id: string;
  date: string;
  steps: number;
  heartRate: number;
  exerciseMinutes: number;
  sleepHours: number;
  source: "Apple Watch" | "Wear OS" | "Manual";
};

export type Patient = {
  id: string;
  name: string;
  nickname?: string;
  email: string;
  cpf: string;
  password?: string;
  passwordHash: string;
  birthDate: string;
  sex: string;
  age: number;
  heightCm: number;
  initialWeight: number;
  currentWeight: number;
  targetWeight: number;
  goal30: number;
  goal60: number;
  goal90: number;
  doctor: string;
  plan: string;
  notes: string;
  rememberMe?: boolean;
  emailVerified?: boolean;
  acceptedTerms: boolean;
  acceptedPrivacy: boolean;
  firstAccessComplete: boolean;
  objective?: "lose" | "maintain" | "gain";
  monthlyWeightGoal?: number;
  favoriteWeeklyReward?: string;
  favoriteMonthlyReward?: string;
  profilePhoto?: string;
};

export type AppData = {
  startedAt: string;
  patientId: string;
  initialWeight: number;
  currentWeight: number;
  targetWeight: number;
  goal30: number;
  goal60: number;
  goal90: number;
  wakeTime?: string;
  sleepTime: string;
  mealTargetGrams: number;
  waterGoalMl: number;
  meals: Meal[];
  weights: WeightEntry[];
  water: WaterEntry[];
  barcodeItems: BarcodeItem[];
  symptoms: SymptomEntry[];
  bodyPhotos: BodyPhoto[];
  bodyMeasures: BodyMeasure[];
  marketItems: MarketItem[];
  healthProfile: HealthProfile;
  habits: Habit[];
  travelMode: TravelMode;
  objectives: PersonalObjective[];
  seasons: Season[];
  timeCapsule: string;
  coins: number;
  records: PersonalRecords;
  settings: AppSettings;
  dailyFeedback: Record<string, string>;
  syncQueue: string[];
  secretAchievements: string[];
  checkups: CheckupEntry[];
  sleeps: SleepEntry[];
  watchEntries: WatchEntry[];
  snackRewards: number;
  snackSpent: number;
  homeSavings: number;
  moodByDate: Record<string, string>;
  reflectionByDate: Record<string, string>;
  openedRewardBoxes: string[];
  plannedMeals: PlannedMeal[];
  checklistByDate: Record<string, ChecklistState>;
  xp: number;
  streak: number;
  lastCompletedDate?: string;
  rewards: RewardState;
  shopRewards: ShopReward[];
  achievements: string[];
};
