import type { ButtonHTMLAttributes, ReactNode } from "react";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  children: ReactNode;
  variant?: "primary" | "ghost" | "warning";
};

export function ActionButton({ children, variant = "primary", className = "", ...props }: Props) {
  const styles = {
    primary: "border-signal bg-signal text-base hover:bg-bone",
    ghost: "border-graphite bg-field text-bone hover:border-signal",
    warning: "border-danger bg-danger text-base hover:bg-bone"
  };

  return (
    <button
      className={`min-h-12 rounded-sm border px-4 py-3 text-center text-sm font-black uppercase tracking-normal transition disabled:cursor-not-allowed disabled:opacity-50 ${styles[variant]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
