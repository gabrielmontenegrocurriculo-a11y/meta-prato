import type { AppData, ChecklistState } from "../types";
import { addDays, dateKeyFrom, daysBetween, isSameMonth, isSameWeek, todayKey } from "./date";
import { defaultChecklist } from "./storage";

export const clamp = (value: number, min = 0, max = 100) => Math.max(min, Math.min(max, value));

export const checklistScore = (checklist: ChecklistState) => {
  const values = Object.values(checklist);
  return values.filter(Boolean).length / values.length;
};

export const getTodayChecklist = (data: AppData) => data.checklistByDate[todayKey()] ?? defaultChecklist();

export const getWaterToday = (data: AppData) =>
  data.water.filter((entry) => entry.date === todayKey()).reduce((sum, entry) => sum + entry.amount, 0);

export const getMealDays = (data: AppData, filter: (date: string) => boolean) =>
  new Set(data.meals.filter((meal) => filter(meal.date)).map((meal) => meal.date)).size;

export const getWaterDays = (data: AppData, filter: (date: string) => boolean) =>
  new Set(data.water.filter((entry) => filter(entry.date)).map((entry) => entry.date)).size;

export const progressFor = (data: AppData, filter: (date: string) => boolean) => {
  const relevant = Object.entries(data.checklistByDate).filter(([date]) => filter(date));
  if (!relevant.length) return 0;
  const score = relevant.reduce((sum, [, checklist]) => sum + checklistScore(checklist), 0) / relevant.length;
  return Math.round(score * 100);
};

export const dailyProgress = (data: AppData) => Math.round(checklistScore(getTodayChecklist(data)) * 100);

export const weeklyProgress = (data: AppData) => progressFor(data, isSameWeek);

export const monthlyProgress = (data: AppData) => progressFor(data, isSameMonth);

export const weeklyUnlocked = (data: AppData) =>
  weeklyProgress(data) >= 80 && getMealDays(data, isSameWeek) >= 5 && getWaterDays(data, isSameWeek) >= 5;

export const monthlyUnlocked = (data: AppData) => {
  const monthProgress = monthlyProgress(data);
  const weeklyWeights = new Set(data.weights.filter((entry) => isSameMonth(entry.date)).map((entry) => weekNumber(entry.date)));
  return monthProgress >= 80 && weeklyWeights.size >= 4 && data.streak >= 7;
};

export const nextReward = (data: AppData) => {
  if (monthlyUnlocked(data)) return "Super recompensa mensal pronta";
  if (weeklyUnlocked(data)) return "Recompensa semanal pronta";
  const missingWeekly = Math.max(0, 80 - weeklyProgress(data));
  return `Faltam ${missingWeekly}% para liberar a recompensa semanal`;
};

export const estimateMealGrams = (file: File) => {
  const mb = file.size / 1024 / 1024;
  const base = 380 + Math.round(mb * 110);
  return clamp(base, 220, 850);
};

export const updateStreak = (data: AppData) => {
  const today = todayKey();
  const checklist = data.checklistByDate[today];
  if (!checklist || checklistScore(checklist) < 0.8 || data.lastCompletedDate === today) return data;

  const yesterday = dateKeyFrom(addDays(new Date(), -1));
  const streak = data.lastCompletedDate === yesterday ? data.streak + 1 : 1;
  return { ...data, streak, lastCompletedDate: today };
};

export const addXp = (data: AppData, amount: number) => {
  const xp = data.xp + amount;
  const achievements = new Set(data.achievements);
  if (xp >= 250) achievements.add("Operador consistente");
  if (data.streak >= 7) achievements.add("Semana blindada");
  if (getWaterToday(data) >= data.waterGoalMl) achievements.add("Hidratacao em dia");
  return { ...data, xp, achievements: [...achievements] };
};

export const levelForXp = (xp: number) => Math.floor(xp / 300) + 1;

export const daysRemainingToGoal = (data: AppData) => {
  const start = new Date(data.startedAt);
  const elapsed = Math.max(0, daysBetween(start, new Date()));
  return Math.max(0, 90 - elapsed);
};

export const weightGoalForDay = (data: AppData) => {
  const start = new Date(data.startedAt);
  const elapsed = Math.max(0, daysBetween(start, new Date()));
  if (elapsed <= 30) return data.goal30;
  if (elapsed <= 60) return data.goal60;
  if (elapsed <= 90) return data.goal90;
  return data.targetWeight;
};

const weekNumber = (dateKey: string) => {
  const date = new Date(`${dateKey}T12:00:00`);
  const first = new Date(date.getFullYear(), 0, 1);
  return Math.ceil(((date.getTime() - first.getTime()) / 86400000 + first.getDay() + 1) / 7);
};
