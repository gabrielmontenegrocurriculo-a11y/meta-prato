import type { Patient } from "../types";

export const patients: Patient[] = [
  {
    id: "paciente-gabriel",
    name: "Gabriel Santos",
    nickname: "Guerreiro",
    email: "gabriel@metaprato.app",
    cpf: "11122233344",
    passwordHash: "a2ca37fe6fdc490b8f7ce841e1701a169d2b1697c6b5b5c63f94abb8f9b6d6dd",
    birthDate: "1994-03-18",
    sex: "Masculino",
    age: 32,
    heightCm: 178,
    initialWeight: 160,
    currentWeight: 160,
    targetWeight: 100,
    goal30: 145,
    goal60: 130,
    goal90: 115,
    doctor: "Equipe Meta Prato",
    plan: "Controle de gramas, agua e rotina",
    notes: "Foco em constancia, registro de pratos e hidratacao diaria.",
    acceptedTerms: true,
    acceptedPrivacy: true,
    emailVerified: true,
    firstAccessComplete: true,
    objective: "lose",
    monthlyWeightGoal: 5,
    favoriteWeeklyReward: "Cinema",
    favoriteMonthlyReward: "Restaurante"
  },
  {
    id: "paciente-mariana",
    name: "Mariana Costa",
    nickname: "Mari",
    email: "mariana@metaprato.app",
    cpf: "22233344455",
    passwordHash: "a2ca37fe6fdc490b8f7ce841e1701a169d2b1697c6b5b5c63f94abb8f9b6d6dd",
    birthDate: "1985-07-10",
    sex: "Feminino",
    age: 41,
    heightCm: 165,
    initialWeight: 112,
    currentWeight: 112,
    targetWeight: 82,
    goal30: 105,
    goal60: 96,
    goal90: 88,
    doctor: "Dra. Helena Rocha",
    plan: "Rotina alimentar com recompensas controladas",
    notes: "Priorizar agua, peso semanal e refeicoes planejadas.",
    acceptedTerms: true,
    acceptedPrivacy: true,
    emailVerified: true,
    firstAccessComplete: true,
    objective: "lose",
    monthlyWeightGoal: 4,
    favoriteWeeklyReward: "Sobremesa pequena",
    favoriteMonthlyReward: "Livro"
  },
  {
    id: "paciente-roberto",
    name: "Roberto Lima",
    nickname: "Beto",
    email: "roberto@metaprato.app",
    cpf: "33344455566",
    passwordHash: "a2ca37fe6fdc490b8f7ce841e1701a169d2b1697c6b5b5c63f94abb8f9b6d6dd",
    birthDate: "1973-11-22",
    sex: "Masculino",
    age: 53,
    heightCm: 172,
    initialWeight: 138,
    currentWeight: 138,
    targetWeight: 95,
    goal30: 130,
    goal60: 119,
    goal90: 108,
    doctor: "Dr. Paulo Mendes",
    plan: "Monitoramento diario de agua, prato e peso",
    notes: "Sem punicoes. Trabalhar consistencia e escolhas controladas.",
    acceptedTerms: true,
    acceptedPrivacy: true,
    emailVerified: true,
    firstAccessComplete: true,
    objective: "lose",
    monthlyWeightGoal: 5,
    favoriteWeeklyReward: "Prato especial",
    favoriteMonthlyReward: "Jogo"
  }
];

const CUSTOM_PATIENTS_KEY = "meta-prato-custom-patients-v1";

export type PatientForm = {
  name: string;
  nickname: string;
  birthDate: string;
  sex: string;
  email: string;
  confirmEmail: string;
  cpf: string;
  password: string;
  confirmPassword: string;
  age: number;
  heightCm: number;
  initialWeight: number;
  targetWeight: number;
  doctor: string;
  plan: string;
  notes: string;
  acceptedTerms: boolean;
  acceptedPrivacy: boolean;
};

export const normalizeEmail = (email: string) => email.trim().toLowerCase();

export const passwordRules = (password: string) => ({
  length: password.length >= 8,
  uppercase: /[A-Z]/.test(password),
  number: /\d/.test(password),
  special: /[^A-Za-z0-9]/.test(password)
});

export const isStrongPassword = (password: string) => Object.values(passwordRules(password)).every(Boolean);

export const hashPassword = async (password: string) => {
  const bytes = new TextEncoder().encode(password);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
};

export const loadCustomPatients = (): Patient[] => {
  try {
    const raw = localStorage.getItem(CUSTOM_PATIENTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

export const saveCustomPatients = (customPatients: Patient[]) => {
  localStorage.setItem(CUSTOM_PATIENTS_KEY, JSON.stringify(customPatients));
};

export const getAllPatients = () => [...patients, ...loadCustomPatients()];

export const getServerPatients = async () => {
  try {
    const response = await fetch("/api/patients");
    if (!response.ok) return getAllPatients();
    const serverPatients = (await response.json()) as Patient[];
    serverPatients.forEach(updateStoredPatient);
    return [...patients, ...loadCustomPatients()];
  } catch {
    return getAllPatients();
  }
};

export const findPatient = async (email: string, password: string) => {
  try {
    const response = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    if (response.ok) {
      const result = await response.json();
      updateStoredPatient(result.patient);
      return result.patient as Patient;
    }
  } catch {
    // Local fallback keeps the PWA usable without the server.
  }
  const passwordHash = await hashPassword(password);
  return getAllPatients().find((patient) => normalizeEmail(patient.email) === normalizeEmail(email) && patient.passwordHash === passwordHash);
};

export const registerPatient = async (form: PatientForm) => {
  const allPatients = getAllPatients();
  const email = normalizeEmail(form.email);
  const confirmEmail = normalizeEmail(form.confirmEmail);
  const cpf = onlyDigits(form.cpf);

  if (!form.name.trim()) throw new Error("Informe o nome do paciente.");
  if (!email.includes("@")) throw new Error("Informe um email valido.");
  if (email !== confirmEmail) throw new Error("Os emails nao conferem.");
  if (!form.birthDate) throw new Error("Informe a data de nascimento.");
  if (!form.sex) throw new Error("Informe o sexo.");
  if (!isStrongPassword(form.password)) throw new Error("A senha ainda nao atende todos os requisitos.");
  if (form.password !== form.confirmPassword) throw new Error("As senhas nao conferem.");
  if (!form.acceptedTerms || !form.acceptedPrivacy) throw new Error("Aceite os Termos de Uso e a Politica de Privacidade.");
  if (allPatients.some((patient) => normalizeEmail(patient.email) === email)) throw new Error("Este email ja esta cadastrado.");
  if (cpf && allPatients.some((patient) => onlyDigits(patient.cpf) === cpf)) throw new Error("Este CPF ja esta cadastrado.");

  try {
    const response = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    const result = await response.json().catch(() => null);
    if (response.ok && result?.patient) {
      updateStoredPatient(result.patient);
      return result.patient as Patient;
    }
    if (response.status !== 404 && response.status !== 503 && result?.message) throw new Error(result.message);
  } catch (error) {
    if (error instanceof Error && !error.message.includes("Failed to fetch")) throw error;
  }

  const initialWeight = Number(form.initialWeight) || 160;
  const targetWeight = Number(form.targetWeight) || 100;
  const distance = Math.max(1, initialWeight - targetWeight);
  const passwordHash = await hashPassword(form.password);
  const birthDate = new Date(`${form.birthDate}T12:00:00`);
  const age = Number(form.age) || Math.max(1, new Date().getFullYear() - birthDate.getFullYear());
  const patient: Patient = {
    id: `paciente-${crypto.randomUUID()}`,
    name: form.name.trim(),
    nickname: form.nickname.trim(),
    email,
    cpf,
    passwordHash,
    birthDate: form.birthDate,
    sex: form.sex,
    age,
    heightCm: Number(form.heightCm) || 170,
    initialWeight,
    currentWeight: initialWeight,
    targetWeight,
    goal30: Math.max(targetWeight, Math.round((initialWeight - distance * 0.25) * 10) / 10),
    goal60: Math.max(targetWeight, Math.round((initialWeight - distance * 0.5) * 10) / 10),
    goal90: Math.max(targetWeight, Math.round((initialWeight - distance * 0.75) * 10) / 10),
    doctor: form.doctor.trim() || "Equipe Meta Prato",
    plan: form.plan.trim() || "Controle de rotina, agua e refeicoes",
    notes: form.notes.trim() || "Foco em constancia, seguranca e progresso gradual.",
    acceptedTerms: form.acceptedTerms,
    acceptedPrivacy: form.acceptedPrivacy,
    emailVerified: false,
    firstAccessComplete: false
  };

  const customPatients = [...loadCustomPatients(), patient];
  saveCustomPatients(customPatients);
  return patient;
};

export const updateStoredPatient = (patient: Patient) => {
  const customPatients = loadCustomPatients();
  const existsInCustom = customPatients.some((item) => item.id === patient.id);
  if (existsInCustom) {
    saveCustomPatients(customPatients.map((item) => (item.id === patient.id ? patient : item)));
  } else {
    saveCustomPatients([...customPatients, patient]);
  }
};

export const syncPatientToServer = async (patient: Patient) => {
  try {
    await fetch(`/api/patients/${encodeURIComponent(patient.id)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patient)
    });
  } catch {
    // LocalStorage remains the source when the server is offline.
  }
};

export const onlyDigits = (value: string) => value.replace(/\D/g, "");
