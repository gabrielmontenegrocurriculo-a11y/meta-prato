import type { AppData, ChecklistState, Patient } from "../types";

const STORAGE_PREFIX = "meta-prato-data-v2";
const SESSION_KEY = "meta-prato-session-patient";

export const defaultChecklist = (): ChecklistState => ({
  mealRegistered: false,
  platePhoto: false,
  water: false,
  noRepeat: false,
  withinGoal: false,
  weightRegistered: false
});

export const defaultData = (patient?: Patient): AppData => ({
  startedAt: new Date().toISOString(),
  patientId: patient?.id ?? "default",
  initialWeight: patient?.initialWeight ?? 160,
  currentWeight: patient?.currentWeight ?? 160,
  targetWeight: patient?.targetWeight ?? 100,
  goal30: patient?.goal30 ?? 145,
  goal60: patient?.goal60 ?? 130,
  goal90: patient?.goal90 ?? 115,
  sleepTime: "23:00",
  mealTargetGrams: 550,
  waterGoalMl: 2300,
  meals: [],
  weights: [
    {
      id: crypto.randomUUID(),
      date: new Date().toISOString().slice(0, 10),
      weight: patient?.currentWeight ?? 160
    }
  ],
  water: [],
  barcodeItems: [],
  symptoms: [],
  bodyPhotos: [],
  bodyMeasures: [],
  marketItems: [
    { id: "agua", name: "Agua sem acucar", type: "shopping" },
    { id: "frango", name: "Frango", type: "favorite" },
    { id: "refrigerante", name: "Refrigerante", type: "blocked" }
  ],
  healthProfile: {
    medicines: "",
    allergies: "",
    conditions: ""
  },
  habits: [
    { id: "agua-acordar", name: "Beber agua ao acordar", doneDates: [] },
    { id: "devagar", name: "Comer devagar", doneDates: [] },
    { id: "sem-repetir", name: "Nao repetir prato", doneDates: [] },
    { id: "dormir", name: "Dormir antes do horario", doneDates: [] },
    { id: "caminhar", name: "Caminhar", doneDates: [] }
  ],
  travelMode: {
    active: false,
    location: "",
    timeShift: 0
  },
  objectives: [
    { id: "roupa", text: "Entrar em uma roupa especifica" },
    { id: "condicionamento", text: "Melhorar condicionamento" },
    { id: "evento", text: "Preparar-se para um evento" }
  ],
  seasons: [
    { id: "s1", name: "Temporada 1 - Operacao -15 kg", targetLoss: 15, reward: "Medalha da arrancada" },
    { id: "s2", name: "Temporada 2 - Operacao -30 kg", targetLoss: 30, reward: "Medalha da constancia" },
    { id: "s3", name: "Temporada 3 - Operacao Meta Final", targetLoss: 60, reward: "Relatorio final" }
  ],
  timeCapsule: "",
  coins: 0,
  records: {
    longestStreak: 0,
    maxWaterMl: 0,
    maxMonthlyLoss: 0,
    maxMealsDay: 0
  },
  settings: {
    theme: "military",
    haptics: true,
    smartNotifications: true,
    cloudBackup: false,
    appleHealth: false,
    googleFit: false,
    seasonalEvents: true
  },
  dailyFeedback: {},
  syncQueue: [],
  secretAchievements: [],
  checkups: [],
  sleeps: [],
  watchEntries: [],
  snackRewards: 0,
  snackSpent: 0,
  homeSavings: 0,
  moodByDate: {},
  reflectionByDate: {},
  openedRewardBoxes: [],
  plannedMeals: [],
  checklistByDate: {},
  xp: 0,
  streak: 0,
  rewards: {
    weekly: "Recompensa controlada",
    monthly: "Super recompensa controlada"
  },
  shopRewards: [
    { id: "big-mac", name: "Big Mac", cost: 500 },
    { id: "pizza", name: "Pizza", cost: 700 },
    { id: "cinema", name: "Cinema", cost: 1500 },
    { id: "livro", name: "Livro", cost: 1000 },
    { id: "jogo", name: "Jogo", cost: 3000 }
  ],
  achievements: []
});

const keyFor = (patientId: string) => `${STORAGE_PREFIX}-${patientId}`;

export const loadData = (patient?: Patient): AppData => {
  try {
    const raw = localStorage.getItem(keyFor(patient?.id ?? "default"));
    if (!raw) return defaultData(patient);
    return { ...defaultData(patient), ...JSON.parse(raw), patientId: patient?.id ?? "default" };
  } catch {
    return defaultData(patient);
  }
};

export const saveData = (data: AppData, patientId = data.patientId) => {
  localStorage.setItem(keyFor(patientId), JSON.stringify(data));
};

export const loadServerData = async (patientId: string): Promise<AppData | null> => {
  try {
    const response = await fetch(`/api/data/${encodeURIComponent(patientId)}`);
    if (!response.ok) return null;
    const result = await response.json();
    return result.data ?? null;
  } catch {
    return null;
  }
};

export const saveServerData = async (data: AppData, patientId = data.patientId) => {
  try {
    await fetch(`/api/data/${encodeURIComponent(patientId)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ data })
    });
    return true;
  } catch {
    return false;
  }
};

export const loadSessionPatientId = () => localStorage.getItem(SESSION_KEY);

export const saveSessionPatientId = (patientId: string) => {
  localStorage.setItem(SESSION_KEY, patientId);
};

export const clearSessionPatientId = () => {
  localStorage.removeItem(SESSION_KEY);
};
